<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting("E_ALL");
ini_set("display_errors", 1);
if (isset($HTTP_RAW_POST_DATA)) {
    $input = $HTTP_RAW_POST_DATA;
} else {
    $input = implode("\r\n", file('php://input'));
}
require_once('../lib/nusoap-0.9.5/lib/nusoap.php');
require('../modelo/shc.php');

$server = new soap_server;
$ns = "http://localhost/SHC_Servicio/vista/servicio_web.php";
$server->configurewsdl('Servicio_Web', $ns);


/*listaPerfil 
listaPerfilPorId
agregarPerfil($nombre)
modificaPerfil($id_perfil,$nombre,$estado)
obtenerCodigoPerfil($nombre_perfil)
eliminaPerfil($nombre_perfil)*/
        
/// Perfil

//Lista de Perfil
$server->register("listaProvincias", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Id
$server->register("listaProvinciaXCodigo", array(
'cod_provincia' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///Obtener Código perfil
$server->register("ObtenerCodigoProvincia", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil 
$server->register("agregaProvincias", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil 
$server->register("modificaProvincias", array(
'id_provincia' => 'xsd:int',
'nombre_provincia' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil
$server->register("eliminaProvincias", array(
'id_provincia' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

$server->service($HTTP_RAW_POST_DATA);
