<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
         <?php
        require_once('lib/lib/nusoap.php');
         //url del webservice que invocaremos
        //$wsdl="http://localhost:8080/Base_practica/vista/empleado_servicio.php?1WSDL";
        //Variables
        $client=new nusoap_client("http://localhost:8080/Base_practica/vista/empleado_servicio.php?wsdl",'WSDL');
        $err = $client->getError();
        if ($err) {	echo 'Error en Constructor' . $err ; } 
               
               
   $param=array('id'=>1); 
   $resultado2 = $client->call('listaPerfilPorId',$param);

   $param=array('nombre'=>'Mateo');
   $resultado2 = $client->call('agregarPerfil', $param);

   $id=array('id'=>1);
   $nombre=array('nombre'=>'Manuel');
   $estado=array('estado'=>'activo');
   $resultado2 = $client->call('modificaPerfil', $id,$nombre,$estado);

   $nombre_perfils=array('nombre'=>'Mateo');
   $resultado2 = $client->call('obtenerCodigoPerfil', $nombre_perfils);

   $nombre_perfil=array('nombre'=>'Manuel');
   $resultado2 = $client->call('eliminaPerfil', $nombre_perfil);
          
        if ($client->fault) { // si
            $error = $client->getError();
        if ($error) { // Hubo algun error
                echo 'Error:  ' . $client->faultstring;
            }

            die();
        }
        
             
        if ($client->fault) {
	echo 'Fallo';
	print_r($resultado);
        } else {	// Chequea errores
	$err = $client->getError();
	if ($err) {		
		echo 'Error' . $err ;
	} else {		// Muestra el resultado
		echo 'Resultado';
		print_r ($resultado2);
        
	}
        }
        
        ?>
    </body>
</html>
