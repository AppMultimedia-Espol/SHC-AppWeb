<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        require_once('lib/nusoap-0.9.5/lib/nusoap.php');
        
         //url del webservice que invocaremos
        $wsdl="http://localhost/SHC_Servicio/vista/servicio_web.php?wsdl";
        //Variables
        
        $client=new nusoap_client($wsdl);
        $err = $client->getError();
        if ($err) {	echo 'Error en Constructor' . $err ; } 
              
          
        //Resultado

        //Probar Funcion1:
        $resultado = $client->call('listaPerfil');
 
        //Probar Funcion2:
        //$param=array('nombre_perfil'=>'ADMINISTRADOR');
        //$resultado = $client->call('listaPerfilPorNombre', $param);
       
        //Probar Funcion3:
        //$param=array('id_perfil'=>1); 
        //$resultado = $client->call('listaPerfilPorId',$param);
        
        //Probar Funcion4:
        //$param=array('nombre_perfil'=>'PACIENTE'); 
        //$resultado = $client->call('obtenerCodigoPerfil',$param);
        
        //Probar Funcion5:
        //$param=array('nombre'=>'EMPLEADO'); 
        //$resultado = $client->call('agregarPerfil',$param);
        
        //Probar Funcion6:
        //$param=array('id'=>3,'nombre'=>'EMPLEADO_MEDICO','estado'=>'Activo'); 
        //$resultado = $client->call('modificaPerfil',$param);
        
        //Probar Funcion7:
        //$param=array('nombre_perfil'=>'EMPLEADO_MEDICO'); 
        //$resultado = $client->call('eliminaPerfilPorNombre',$param);
        
        //Probar Funcion8:
        //$param=array('id_perfil'=>3); 
        //$resultado = $client->call('eliminaPerfil',$param);
        
            if ($client->fault) {
                echo 'Fallo';
                print_r($resultado);
            } else {	// Chequea errores
            $err = $client->getError();
                if ($err) {		// Muestra el error
                        echo 'Error' . $err ;
                } else {		// Muestra el resultado
                        echo "<br>";
                        echo 'Consulta con parametro:';
                        print_r ($resultado);
                }
            }
        
        ?>
    </body>
</html>
