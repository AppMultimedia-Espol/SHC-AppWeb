<?php
include($_SERVER["DOCUMENT_ROOT"] . '/SHC_Servicio/db/Conexion.class.php');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of shc
 *
 * @author nathaly murillo
 */

function listaPerfil() {
    
    $sql = "select * from perfil where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorNombre($nombre_perfil) {
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";   
    }else{
        
        $sql = "select * from perfil where nombre='$nombre_perfil'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorId($id_perfil) {
    
    if($id_perfil=='')
    {
        return "Ingrese el codigo del perfil";   
    }else{
        
        $sql = "select * from perfil where id=$id_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfil($nombre_perfil){
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";  
    }else{
        $db = new conexion();
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];
        
        return $id_perfil;
    } 
 
}

function agregarPerfil($nombre) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO perfil(nombre,estado)";
    $sql.=" VALUES(UPPER('$nombre'),'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil";
    } else 
    {
        return "Se Guardo el Perfil exitosamente";
    }
}

function modificaPerfil($id_perfil,$nombre,$estado) {
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil";
    }else{
        return "Se Modifico el Perfil exitosamente";
    }
}
               
function eliminaPerfilPorNombre($nombre_perfil) {

    $id_perfil=obtenerCodigoPerfil($nombre_perfil);
    
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

function eliminaPerfil($id_perfil) {

    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}