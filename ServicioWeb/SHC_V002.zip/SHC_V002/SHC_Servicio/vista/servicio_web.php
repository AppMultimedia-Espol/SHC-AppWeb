<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting("E_ALL");
ini_set("display_errors", 1);
if (isset($HTTP_RAW_POST_DATA)) {
    $input = $HTTP_RAW_POST_DATA;
} else {
    $input = implode("\r\n", file('php://input'));
}
require_once('../lib/nusoap-0.9.5/lib/nusoap.php');
require('../modelo/shc.php');

$server = new soap_server;
$ns = "http://localhost/SHC_Servicio/vista/servicio_web.php";
$server->configurewsdl('Servicio_Web', $ns);


/*listaPerfil
listaPerfilPorId
listaPerfilPorNombre($nombre_perfil)
listaPerfilPorId($id_perfil)
obtenerCodigoPerfil($nombre_perfil)
agregarPerfil($nombre)
modificaPerfil($id_perfil,$nombre,$estado)
eliminaPerfilPorNombre($nombre_perfil)
eliminaPerfil($nombre_perfil)*/
        
/// Perfil

//Lista de Perfil
$server->register("listaPerfil", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Nombre
$server->register("listaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Id
$server->register("listaPerfilPorId", array(
'id_Perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código perfil
$server->register("obtenerCodigoPerfil", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil 
$server->register("agregarPerfil", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil 
$server->register("modificaPerfil", array(
'id_perfil' => 'xsd:int',
'nombre' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil por Nombre
$server->register("eliminaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:nombre',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil
$server->register("eliminaPerfil", array(
'id_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

$server->service($HTTP_RAW_POST_DATA);
