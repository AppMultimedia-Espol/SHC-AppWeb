<?php
include($_SERVER["DOCUMENT_ROOT"] . '/SHC_Servicio/db/Conexion.class.php');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of shc
 *
 * @author Grupo Servicios Web
 */

function listaPerfil() {
    
    $sql = "select * from perfil where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorNombre($nombre_perfil) {
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";   
    }else{
        
        $sql = "select * from perfil where nombre='$nombre_perfil'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorId($id_perfil) {
    
    if($id_perfil=='')
    {
        return "Ingrese el codigo del perfil";   
    }else{
        
        $sql = "select * from perfil where id=$id_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfil($nombre_perfil){
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";  
    }else{
        $db = new conexion();
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];
        
        return $id_perfil;
    } 
 
}

function agregarPerfil($nombre) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO perfil(nombre,estado)";
    $sql.=" VALUES(UPPER('$nombre'),'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil";
    } else 
    {
        return "Se Guardo el Perfil exitosamente";
    }
}

function modificaPerfil($id_perfil,$nombre,$estado) {
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil";
    }else{
        return "Se Modifico el Perfil exitosamente";
    }
}
               
function eliminaPerfilPorNombre($nombre_perfil) {

    $id_perfil=obtenerCodigoPerfil($nombre_perfil);
    
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

function eliminaPerfil($id_perfil) {

    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Opcion
function listaOpcion() {
    
    $sql = "select * from opcion where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorNombre($nombre_opcion) {
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la Opcion";   
    }else{
        
        $sql = "select * from opcion where nombre='$nombre_opcion'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorId($id_opcion) {
    
    if($id_opcion=='')
    {
        return "Ingrese el codigo de la Opcion";   
    }else{
        
        $sql = "select * from opcion where id=$id_opcion";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcion($nombre_opcion){
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        $sql2 = "select * from opcion where nombre = '$nombre_opcion'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_opcion=$fila[0];
        
        return $id_opcion;
    } 
 
}

function agregarOpcion($nombre_opcion,$url_opcion) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO opcion(nombre,url,estado)";
    $sql.=" VALUES(UPPER('$nombre_opcion'),'$url_opcion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion";
    } else 
    {
        return "Se Guardo la Opcion exitosamente";
    }
}

function modificaOpcion($id_opcion,$nombre_opcion,$url_opcion, $estado) {
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " nombre='$nombre_opcion',url='$url_opcion',estado='$estado'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion";
    }else{
        return "Se Modifico la Opcion exitosamente";
    }
}
               
function eliminaOpcionPorNombre($nombre_opcion) {

    $id_opcion=obtenerCodigoOpcion($nombre_opcion);
    
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

function eliminaOpcion($id_opcion) {

    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Opcion Perfil
function listaOpcionPerfil() {
    
    $sql = "select p.nombre,o.nombre,o.url from perfil p,opcion o,opcion_perfil op";
    $sql.=" where op.id_perfil=p.id and op.id_opcion=o.id and op.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaOpcionPerfilPorId($id_opcion_perfil) {
    
    if($id_opcion_perfil=='')
    {
        return "Ingrese el codigo de la Opcion Perfil";   
    }else{
        
        $sql = "select * from opcion_perfil where id=$id_opcion_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcionPerfil($nombre_perfil,$nombre_opcion){
    
    if($nombre_opcion=='' || $nombre_perfil='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from opcion where nombre = '$nombre_opcion'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_opcion=$fila1[0];
        
        $sql4 = "select id from opcion_perfil where id_opcion = $id_opcion and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_opcion_perfil=$fila2[0];
        
        return $id_opcion_perfil;
    } 
 
}

function agregarOpcionPerfil($nombre_perfil,$nombre_opcion) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_opcion=$fila[0];
    
    $sql3 = "select id from opcion where nombre = '$nombre_opcion'";
     
    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_perfil=$fila1[0];
    
    $sql = "INSERT INTO opcion(id_perfil,id_opcion,estado)";
    $sql.=" VALUES($id_perfil,$id_opcion,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion Perfil";
    } else 
    {
        return "Se Guardo la Opcion Perfil exitosamente";
    }
}

function modificaOpcionPerfil($id_opcion_perfil,$id_opcion,$id_perfil, $estado) {
    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " id_opcion=$id_opcion,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion Perfil";
    }else{
        return "Se Modifico la Opcion Perfil exitosamente";
    }
}

function eliminaOpcionPerfil($id_opcion_perfil) {

    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion Perfil";
    }else{
        return "Se Elimino la Opcion Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Usuario

function listaUsuario() {
    
    $sql = "select * from usuario where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaUsuarioPorId($id_usuario) {
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo del usuario";   
    }else{
        
        $sql = "select * from usuario where id=$id_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoUsuario($usuario,$clave){
    
    if($usuario=='' || $clave=='')
    {
        return "Ingrese el nombre del usuario";  
    }else{
        $db = new conexion();
        $sql2 = "select id from usuario where usuario = '$nombre_usuario' and clave='$clave'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_usuario=$fila[0];
        
        return $id_usuario;
    } 
 
}

function agregarUsuario($nombre_usuario,$clave_usuario) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO usuario(usuario,clave,estado)";
    $sql.=" VALUES('$nombre_usuario','$clave_usuario','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Usuario";
    } else 
    {
        return "Se Guardo el Usuario exitosamente";
    }
}

function modificaUsuario($id_usuario,$nombre_usuario,$clave_usuario,$estado) {
    $sql = "update usuario ";
    $sql.="set";
    $sql.= " usuario='$nombre_usuario',clave='$clave_usuario',estado='$estado'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Usuario";
    }else{
        return "Se Modifico el Usuario exitosamente";
    }
}
               
function eliminaUsuarioPorNombre($nombre_usuario,$clave_usuario) {

    $id_usuario=obtenerCodigoUsuario($nombre_usuario,$clave_usuario);
    
    $sql ="update usuario ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

function eliminaUsuario($id_usuario) {

    $sql = "update usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Perfil Usuario
function listaPerfilUsuario() {
    
    $sql = "select u.usuario,u.clave,p.nombre from usuario u, perfil p, perfil_usuario per";
    $sql.=" where per.id_usuario= u.id and per.id_perfil=p.id and per.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaPerfilUsuarioPorId($id_perfil_usuario) {
    
    if($id_perfil_usuario=='')
    {
        return "Ingrese el codigo del perfil usuario";   
    }else{
        
        $sql = "select * from  perfil_usuario where id=$id_perfil_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfilUsuario($nombre_perfil,$usuario,$clave){
    
    if($nombre_perfil=='' || $usuario='' || $clave='')
    {
        return "Ingrese el nombre perfil, el usuario y clave";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_usuario=$fila1[0];
        
        $sql4 = "select id from perfil_usuario where id_usuario = $id_usuario and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_perfil_usuario=$fila2[0];
        
        return $id_perfil_usuario;
    } 
 
}

function agregarPerfilUsuario($nombre_perfil,$usuario,$clave) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_perfil=$fila[0];

    $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_usuario=$fila1[0];
        
    $sql = "INSERT INTO perfil_usuario(id_usuario, id_perfil, estado)";
    $sql.=" VALUES($id_usuario,$id_perfil,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil de Usuario";
    } else 
    {
        return "Se Guardo el Perfil de Perfil de Usuario exitosamente";
    }
}

function modificaPerfilUsuario($id_perfil_usuario,$id_usuario,$id_perfil,$estado){
    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.=" id_usuario=$id_usuario,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil de Usuario";
    }else{
        return "Se Modifico el Perfil de Usuario exitosamente";
    }
}
               
function eliminaPerfilUsuario($id_perfil_usuario){

    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil de Usuario";
    }else{
        return "Se Elimino el Perfil de Usuario exitosamente";
    }
}
