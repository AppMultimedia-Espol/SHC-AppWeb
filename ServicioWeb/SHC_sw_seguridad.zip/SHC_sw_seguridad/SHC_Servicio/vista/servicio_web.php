<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting("E_ALL");
ini_set("display_errors", 1);
if (isset($HTTP_RAW_POST_DATA)) {
    $input = $HTTP_RAW_POST_DATA;
} else {
    $input = implode("\r\n", file('php://input'));
}
require_once('../lib/nusoap-0.9.5/lib/nusoap.php');
require('../modelo/shc.php');

$server = new soap_server;
$ns = "http://localhost/SHC_Servicio/vista/servicio_web.php";
$server->configurewsdl('Servicio_Web', $ns);


/*listaPerfil
listaPerfilPorId
listaPerfilPorNombre($nombre_perfil)
listaPerfilPorId($id_perfil)
obtenerCodigoPerfil($nombre_perfil)
agregarPerfil($nombre)
modificaPerfil($id_perfil,$nombre,$estado)
eliminaPerfilPorNombre($nombre_perfil)
eliminaPerfil($nombre_perfil)*/
        
/// Perfil

//Lista de Perfil
$server->register("listaPerfil", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Nombre
$server->register("listaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Id
$server->register("listaPerfilPorId", array(
'id_Perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código perfil
$server->register("obtenerCodigoPerfil", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil 
$server->register("agregarPerfil", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil 
$server->register("modificaPerfil", array(
'id_perfil' => 'xsd:int',
'nombre' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil por Nombre
$server->register("eliminaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:nombre',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil
$server->register("eliminaPerfil", array(
'id_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista de Opcion
$server->register("listaOpcion", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion por Nombre
$server->register("listaOpcionPorNombre", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion por Id
$server->register("listaOpcionPorId", array(
'id_opcion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Opcion
$server->register("obtenerCodigoOpcion", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Agregar Opcion
$server->register("agregarOpcion", array(
'nombre_opcion' => 'xsd:string',
'url_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Opcion
$server->register("modificaOpcion", array(
'id_opcion' => 'xsd:int',
'nombre_opcion' => 'xsd:string',
'url_opcion' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion por Nombre
$server->register("eliminaOpcionPorNombre", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion
$server->register("eliminaOpcion", array(
'id_opcion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista Opcion Perfil
$server->register("listaOpcionPerfil", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion Perfil por Id
$server->register("listaOpcionPerfilPorId", array(
'id_opcion_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);
        
//Obtener Código Opcion Perfil
$server->register("obtenerCodigoOpcionPerfil", array(
'nombre_perfil' => 'xsd:string',
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Opcion Perfil
$server->register("agregarOpcionPerfil", array(
'nombre_perfil' => 'xsd:string',
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Opcion Perfil  
$server->register("modificaOpcionPerfil", array(
'id_opcion_perfil' => 'xsd:int',
'id_opcion' => 'xsd:int',
'id_perfil' => 'xsd:int',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion Perfil
$server->register("eliminaOpcionPerfil", array(
'id_opcion_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista de Usuario
$server->register("listaUsuario", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Usuario por Id
$server->register("listaUsuarioPorId", array(
'id_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código usuario
$server->register("obtenerCodigoUsuario", array(
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Usuario
$server->register("agregarUsuario", array(
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Usuario 
$server->register("modificaUsuario", array(
'id_usuario' => 'xsd:int',
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Usuario por Nombre
$server->register("eliminaUsuarioPorNombre", array(
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Usuario
$server->register("eliminaUsuario", array(
'id_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista Perfil Usuario
$server->register("listaPerfilUsuario", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil Usuario por Id
$server->register("listaPerfilUsuarioPorId", array(
'id_Perfil_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Perfil Usuario
$server->register("obtenerCodigoPerfilUsuario", array(
'nombre_perfil' => 'xsd:string',
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil Usuario
$server->register("agregarPerfilUsuario", array(
'nombre_perfil' => 'xsd:string',
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil Usuario 
$server->register("modificaPerfilUsuario", array(
'id_perfil_usuario' => 'xsd:int',
'id_usuario' => 'xsd:int',
'id_perfil' => 'xsd:int',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil Usuario
$server->register("eliminaPerfilUsuario", array(
'id_perfil_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);


$server->service($HTTP_RAW_POST_DATA);
