<?php
include($_SERVER["DOCUMENT_ROOT"] . '/SHC_Servicio/db/Conexion.class.php');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of shc
 *
 * @author Grupo Servicios Web
 */

function listaPerfil() {
    
    $sql = "select * from perfil where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorNombre($nombre_perfil) {
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";   
    }else{
        
        $sql = "select * from perfil where nombre='$nombre_perfil'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorId($id_perfil) {
    
    if($id_perfil=='')
    {
        return "Ingrese el codigo del perfil";   
    }else{
        
        $sql = "select * from perfil where id=$id_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfil($nombre_perfil){
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";  
    }else{
        $db = new conexion();
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];
        
        return $id_perfil;
    } 
 
}

function agregarPerfil($nombre) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO perfil(nombre,estado)";
    $sql.=" VALUES('$nombre','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil";
    } else 
    {
        return "Se Guardo el Perfil exitosamente";
    }
}

function modificaPerfil($id_perfil,$nombre,$estado) {
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil";
    }else{
        return "Se Modifico el Perfil exitosamente";
    }
}
               
function eliminaPerfilPorNombre($nombre_perfil) {

    $id_perfil=obtenerCodigoPerfil($nombre_perfil);
    
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

function eliminaPerfil($id_perfil) {

    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Opcion
function listaOpcion() {
    
    $sql = "select * from opcion where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorNombre($nombre_opcion) {
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la Opcion";   
    }else{
        
        $sql = "select * from opcion where nombre='$nombre_opcion'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorId($id_opcion) {
    
    if($id_opcion=='')
    {
        return "Ingrese el codigo de la Opcion";   
    }else{
        
        $sql = "select * from opcion where id=$id_opcion";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcion($nombre_opcion){
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        $sql2 = "select id from opcion where nombre = '$nombre_opcion'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_opcion=$fila[0];
        
        return $id_opcion;
    } 
 
}

function agregarOpcion($nombre_opcion,$url_opcion) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO opcion(nombre,url,estado)";
    $sql.=" VALUES('$nombre_opcion','$url_opcion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion";
    } else 
    {
        return "Se Guardo la Opcion exitosamente";
    }
}

function modificaOpcion($id_opcion,$nombre_opcion,$url_opcion, $estado) {
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " nombre='$nombre_opcion',url='$url_opcion',estado='$estado'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion";
    }else{
        return "Se Modifico la Opcion exitosamente";
    }
}
               
function eliminaOpcionPorNombre($nombre_opcion) {

    $id_opcion=obtenerCodigoOpcion($nombre_opcion);
    
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

function eliminaOpcion($id_opcion) {

    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Opcion Perfil
function listaOpcionPerfil() {
    
    $sql = "select p.nombre,o.nombre,o.url from perfil p,opcion o,opcion_perfil op";
    $sql.=" where op.id_perfil=p.id and op.id_opcion=o.id and op.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaOpcionPerfilPorId($id_opcion_perfil) {
    
    if($id_opcion_perfil=='')
    {
        return "Ingrese el codigo de la Opcion Perfil";   
    }else{
        
        $sql = "select * from opcion_perfil where id=$id_opcion_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionesPorIdPerfil($id_perfil) {
    
    if($id_perfil=='')
    {
        return "Ingrese el codigo de Perfil";   
    }else{
        
        $sql = "select o.nombre from opcion_perfil op,opcion o where op.id_opcion=o.id and op.id_perfil=$id_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcionPerfil($nombre_perfil,$nombre_opcion){
    
    if($nombre_opcion=='' || $nombre_perfil='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from opcion where nombre = '$nombre_opcion'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_opcion=$fila1[0];
        
        $sql4 = "select id from opcion_perfil where id_opcion = $id_opcion and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_opcion_perfil=$fila2[0];
        
        return $id_opcion_perfil;
    } 
 
}

function agregarOpcionPerfil($nombre_perfil,$nombre_opcion) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_opcion=$fila[0];
    
    $sql3 = "select id from opcion where nombre = '$nombre_opcion'";
     
    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_perfil=$fila1[0];
    
    $sql = "INSERT INTO opcion(id_perfil,id_opcion,estado)";
    $sql.=" VALUES($id_perfil,$id_opcion,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion Perfil";
    } else 
    {
        return "Se Guardo la Opcion Perfil exitosamente";
    }
}

function modificaOpcionPerfil($id_opcion_perfil,$id_opcion,$id_perfil, $estado) {
    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " id_opcion=$id_opcion,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion Perfil";
    }else{
        return "Se Modifico la Opcion Perfil exitosamente";
    }
}

function eliminaOpcionPerfil($id_opcion_perfil) {

    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion Perfil";
    }else{
        return "Se Elimino la Opcion Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Usuario

function listaUsuario() {
    
    $sql = "select * from usuario where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaUsuarioPorId($id_usuario) {
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo del usuario";   
    }else{
        
        $sql = "select * from usuario where id=$id_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoUsuario($usuario,$clave){
    
    if($usuario=='' || $clave=='')
    {
        return "Ingrese el nombre del usuario";  
    }else{
        $db = new conexion();
        $sql2 = "select id from usuario where usuario = '$nombre_usuario' and clave='$clave'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_usuario=$fila[0];
        
        return $id_usuario;
    } 
 
}

function agregarUsuario($nombre_usuario,$clave_usuario) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO usuario(usuario,clave,estado)";
    $sql.=" VALUES('$nombre_usuario','$clave_usuario','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Usuario";
    } else 
    {
        return "Se Guardo el Usuario exitosamente";
    }
}

function modificaUsuario($id_usuario,$nombre_usuario,$clave_usuario,$estado) {
    $sql = "update usuario ";
    $sql.="set";
    $sql.= " usuario='$nombre_usuario',clave='$clave_usuario',estado='$estado'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Usuario";
    }else{
        return "Se Modifico el Usuario exitosamente";
    }
}
               
function eliminaUsuarioPorNombre($nombre_usuario,$clave_usuario) {

    $id_usuario=obtenerCodigoUsuario($nombre_usuario,$clave_usuario);
    
    $sql ="update usuario ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

function eliminaUsuario($id_usuario) {

    $sql = "update usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Perfil Usuario
function listaPerfilUsuario() {
    
    $sql = "select u.usuario,u.clave,p.nombre from usuario u, perfil p, perfil_usuario per";
    $sql.=" where per.id_usuario= u.id and per.id_perfil=p.id and per.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaPerfilUsuarioPorId($id_perfil_usuario) {
    
    if($id_perfil_usuario=='')
    {
        return "Ingrese el codigo del perfil usuario";   
    }else{
        
        $sql = "select * from  perfil_usuario where id=$id_perfil_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfilDesdePerfilUsuario($id_usuario){
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo usuario";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id_perfil from perfil_usuario where id_usuario = $id_usuario";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];
        
        return $id_perfil;
    } 
 
}

function obtenerNombrePerfil($id_usuario){
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo usuario";  
    }else{
        $db = new conexion();
        
        $sql2 = "select p.nombre from perfil_usuario ps, perfil p where ps.id_perfil=p.id and ps.id_usuario = $id_usuario";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $nombre_perfil=$fila[0];
        
        return $nombre_perfil;
    } 
 
}

function obtenerCodigoPerfilUsuario($nombre_perfil,$usuario,$clave){
    
    if($nombre_perfil=='' || $usuario='' || $clave='')
    {
        return "Ingrese el nombre perfil, el usuario y clave";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_usuario=$fila1[0];
        
        $sql4 = "select id from perfil_usuario where id_usuario = $id_usuario and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_perfil_usuario=$fila2[0];
        
        return $id_perfil_usuario;
    } 
 
}

function agregarPerfilUsuario($nombre_perfil,$usuario,$clave) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_perfil=$fila[0];

    $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_usuario=$fila1[0];
        
    $sql = "INSERT INTO perfil_usuario(id_usuario, id_perfil, estado)";
    $sql.=" VALUES($id_usuario,$id_perfil,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil de Usuario";
    } else 
    {
        return "Se Guardo el Perfil de Perfil de Usuario exitosamente";
    }
}

function modificaPerfilUsuario($id_perfil_usuario,$id_usuario,$id_perfil,$estado){
    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.=" id_usuario=$id_usuario,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil de Usuario";
    }else{
        return "Se Modifico el Perfil de Usuario exitosamente";
    }
}
               
function eliminaPerfilUsuario($id_perfil_usuario){

    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil de Usuario";
    }else{
        return "Se Elimino el Perfil de Usuario exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Provincia

function listaProvincia() {
    
    $sql = "select * from provincia where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaProvinciaPorNombre($nombre_provincia) {
    
    if($nombre_provincia=='')
    {
        return "Ingrese el nombre de la provincia";   
    }else{
        
        $sql = "select * from provincia where nombre='$nombre_provincia'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
       
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaProvinciaPorId($id_provincia) {
    
    if($id_provincia=='')
    {
        return "Ingrese el codigo de la provincia";   
    }else{
        
        $sql = "select * from provincia where id=$id_provincia";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoProvincia($nombre_provincia){
    
    if($nombre_provincia=='')
    {
        return "Ingrese el nombre de la provincia";  
    }else{
        $db = new conexion();
        $sql2 = "select id from provincia where nombre = '$nombre_provincia'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_provincia=$fila[0];
        
        return $id_provincia;
    } 
}

function agregarProvincia($nombre_provincia) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO provincia(nombre,estado)";
    $sql.=" VALUES('$nombre_provincia','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Provincia";
    }else 
    {
        return "Se Guardo la Provincia exitosamente";
    }
}

function modificaProvincia($id_provincia,$nombre_provincia,$estado) {
    $sql ="update provincia ";
    $sql.="set";
    $sql.=" nombre='$nombre_provincia',estado='$estado'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Provincia";
    }else{
        return "Se Modifico la provincia exitosamente";
    }
}
               
function eliminaProvinciaPorNombre($nombre_provincia) {

    $id_provincia=obtenerCodigoProvincia($nombre_provincia);
    
    $sql ="update provincia ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la provincia";
    }else{
        return "Se Elimino la provincia exitosamente";
    }
}

function eliminaProvincia($id_provincia) {

    $sql = "update provincia ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Provincia";
    }else{
        return "Se Elimino la Provincia exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Ciudad

function listaCiudad() {
    
    $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
    $sql.=" where c.id_provincia=p.id and c.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaCiudadPorNombre($nombre_ciudad) {
    
    if($nombre_ciudad=='')
    {
        return "Ingrese el nombre de la ciudad";   
    }else{
        
        $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
        $sql.=" where c.id_provincia=p.id and nombre='$nombre_ciudad'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
       
    $datos.= $filas[3];
    $datos.="#";
        
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaCiudadPorId($id_ciudad) {
    
    if($id_ciudad=='')
    {
        return "Ingrese el codigo de la ciudad";   
    }else{
        
        $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
        $sql.=" where c.id_provincia=p.id and id=$id_ciudad";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoCiudad($nombre_provincia,$nombre_ciudad){
    
    if($nombre_ciudad=='')
    {
        return "Ingrese el nombre de la ciudad";  
    }else{
        $db = new conexion();
        
        $sql1="select id from provincia where nombre = '$nombre_provincia'";
        
        $total_reg1 = $db->consulta($sql1);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_provincia=$fila1[0];
        
        $sql2="select * from ciudad where id_provincia=$id_provincia and nombre='$nombre_ciudad'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_ciudad=$fila[0];
        
        return $id_ciudad;
    } 
 
}

function agregarCiudad($nombre_provincia,$nombre_ciudad) 
{
    $db = new conexion(); 
    
    $sql1="select * from provincia where nombre='$nombre_provincia'";
        
    $total_reg1 = $db->consulta($sql1);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_provincia=$fila1[0];
    
    $sql ="INSERT INTO ciudad(id_provincia,nombre,estado)";
    $sql.=" VALUES($id_provincia,'$nombre_ciudad','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Ciudad";
    } else 
    {
        return "Se Guardo la Ciudad exitosamente";
    }
}

function modificaCiudad($id_ciudad,$id_provincia,$nombre_ciudad,$estado) {
    $sql ="update ciudad ";
    $sql.="set";
    $sql.=" id_provincia=$id_provincia,nombre='$nombre_ciudad',estado='$estado'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Ciudad";
    }else{
        return "Se Modifico la Ciudad exitosamente";
    }
}
               
function eliminaCiudadPorNombre($nombre_provincia,$nombre_ciudad) {

    $id_ciudad=obtenerCodigoCiudad($nombre_provincia,$nombre_ciudad);
    
    $sql ="update ciudad ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la ciudad";
    }else{
        return "Se Elimino la ciudad exitosamente";
    }
}

function eliminaCiudad($id_ciudad) {

    $sql ="update ciudad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Ciudad";
    }else{
        return "Se Elimino la Ciudad exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Instituto Salud
function listaInstitutoSalud() {
    
    $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre, i.direccion,i.estado";
    $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and i.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
         $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
         $datos.= $filas[6];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaInstitutoSaludPorNombre($nombre) {
    
    if($nombre=='')
    {
        return "Ingrese la razon social";   
    }else{
        
        $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre, i.direccion,i.estado";
        $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and nombre ='$nombre'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.= $filas[4];
    $datos.="#";

    $datos.= $filas[5];
    $datos.="#";
    
    $datos.= $filas[6];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaInstitutoSaludPorId($id_instituto_salud) {
    
    if($id_instituto_salud=='')
    {
        return "Ingrese el id del instituto social";   
    }else{
        
        $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre,i.direccion,i.estado";
        $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and id=$id_instituto_salud";

    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.= $filas[4];
    $datos.="#";

    $datos.= $filas[5];
    $datos.="#";
    
    $datos.= $filas[6];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoInstitutoSalud($nombre){
    
    if($nombre=='')
    {
        return "Ingrese el nombre del instituto salud";  
    }else{
        $db = new conexion();
        $sql = "select id from instituto_salud where nombre ='$nombre')";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_instituto_salud=$fila[0];
        
        return $id_instituto_salud;
    } 
 
}

function agregarInstitutoSalud($ruc,$razon_social,$nombre,$id_ciudad,$direccion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO instituto_salud(ruc,razon_social,nombre,id_ciudad,direccion,estado)";
    $sql.=" VALUES($ruc,'$razon_social','$nombre',$id_ciudad,'$direccion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Instituto Salud";
    } else 
    {
        return "Se Guardo el Instituto Salud exitosamente";
    }
}

function modificaInstitutoSalud($id_instituto_salud,$ruc,$razon_social,$nombre,$id_ciudad,$direccion,$estado) {
    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" ruc=$ruc,razon_social='$razon_social',nombre='$nombre',id_ciudad=$id_ciudad,direccion='$direccion',estado='$estado'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Instituo Salud";
    }else{
        return "Se Modifico el Instituto Salud exitosamente";
    }
}
               
function eliminaInstitutoSaludPorNombre($nombre) {

    $id_instituto_salud=obtenerCodigoInstitutoSalud($nombre);
    
    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Instituto Salud";
    }else{
        return "Se Elimino el Instituto Salud exitosamente";
    }
}

function eliminaInstitutoSalud($id_instituto_salud) {

    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Instituto Salud";
    }else{
        return "Se Elimino el Instituto Salud exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Especialidad
function listaEspecialidad() {
    
    $sql = "select * from especialidad where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEspecialidadPorNombre($nombre) {
    
    if($nombre=='')
    {
        return "Ingrese el nombre de la especialidad";   
    }else{
        
        $sql = "select * from especialidad where nombre=$nombre";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEspecialidadPorId($id_especialidad) {
    
    if($id_especialidad=='')
    {
        return "Ingrese el id de la especialidad";   
    }else{
        
        $sql = "select * from especialidad where id=$id_especialidad";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEspecialidad($nombre){
    
    if($nombre=='')
    {
        return "Ingrese el nombre de la especialidad";  
    }else{
        $db = new conexion();
        $sql = "select id from especialidad where nombre ='$nombre'";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_especialidad=$fila[0];
        
        return $id_especialidad;
    } 
 
}

function agregarEspecialidad($nombre) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO especialidad(nombre,estado)";
    $sql.=" VALUES('$nombre','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Especialidad";
    } else 
    {
        return "Se Guardo el Especialidad exitosamente";
    }
}

function modificaEspecialidad($id_especialidad,$nombre,$estado){
    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Especialidad";
    }else{
        return "Se Modifico el Especialidad exitosamente";
    }
}
               
function eliminaEspecialidadPorNombre($nombre) {

    $id_especialidad= obtenerCodigoEspecialidad($nombre);
    
    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Especialidad";
    }else{
        return "Se Elimino la Especialidad exitosamente";
    }
}

function eliminaEspecialidad($id_especialidad) {

    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Especialidad";
    }else{
        return "Se Elimino la Especialidad exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Empleado

function listaEmpleado() {
    
    $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
    $sql.=" from empleado e,persona p,telefono t,especialidad es";
    $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoPorEspecialidad($especialidad) {
    
    if($especialidad=='')
    {
        return "Ingrese la especialidad";   
    }else{
        
        $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
        $sql.=" from empleado e,persona p,telefono t,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id and es.nombre='$especialidad'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoPorIdPersona($id_persona) {
    
    if($id_empleado=='')
    {
        return "Ingrese el id del empleado";   
    }else{
        $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
        $sql.=" from empleado e,persona p,telefono t,especialidad es";
        $sql.=" where e.id_persona=$id_persona and e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoPorId($id_empleado) {
    
    if($id_empleado=='')
    {
        return "Ingrese el id del empleado";   
    }else{
        $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
        $sql.=" from empleado e,persona p,telefono t,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id and e.id=$id_empleado";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEmpleado($nombre,$apellido,$especialidad){
    
    if($nombre=='')
    {
        return "Ingrese el nombre del empleado";  
    }else{
        $db = new conexion();
       
        $sql ="select e.id from empleado e,persona p,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and";
        $sql.=" p.nombre ='$nombre' and p.apellido='$apellido' and es.nombre='$especialidad'";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_empleado=$fila[0];
        
        return $id_empleado;
    } 
 
}

function agregarEmpleado($id_persona,$id_especialidad,$id_nivel_instruccion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO empleado(id_persona,id_especialidad,id_nivel_instruccion)";
    $sql.=" VALUES($id_persona,$id_especialidad,$id_nivel_instruccion)";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Empleado";
    } else 
    {
        return "Se Guardo el Empleado exitosamente";
    }
}

function modificaEmpleado($id_empleado,$id_especialidad,$id_nivel_instruccion) {
    $sql ="update empleado ";
    $sql.="set";
    $sql.=" id_especialidad=$id_especialidad,id_nivel_instruccion=$id_nivel_instruccion";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Empleado";
    }else{
        return "Se Modifico el Empleado exitosamente";
    }
}
               
function eliminaEmpleadoPorNombre($nombre,$apellido,$especialidad) {

    $id_empleado=obtenerCodigoEmpleado($nombre,$apellido,$especialidad);
    
    $sql="delete from empleado";
    //$sql.="set";
    //$sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Empleado";
    }else{
        return "Se Elimino el Empleado exitosamente";
    }
}

function eliminaEmpleado($id_empleado) {

    $sql="delete from empleado";
    //$sql.="set";
    //$sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Empleado";
    }else{
        return "Se Elimino el Empleado exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Empleado_Instituto

function listaEmpleadoInstituto() {
    
    $sql ="select ei.id,i.nombre,p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
    $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
    $sql.=" and e.id_persona=p.id and e.id_especialidad=es.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadosporInstituto($nombre_instituto) {
    
    if($nombre_instituto=='')
    {
        return "Ingrese el id del empleado instituto";   
    }else{
        
        $sql ="select p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
        $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
        $sql.=" and i.nombre='$nombre_instituto' and e.id_persona=p.id and e.id_especialidad=es.id";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoInstitutoPorId($id_empleado_instituto) {
    
    if($id_empleado_instituto=='')
    {
        return "Ingrese el id del empleado instituto";   
    }else{
        
        $sql ="select ei.id,i.nombre,p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
        $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
        $sql.=" and e.id_persona=p.id and e.id_especialidad=es.id and ei.id=$id_empleado_instituto";
        
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEmpleadoInstituto($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto){
    
    if($nombre_emp==''||$apellido_emp='')
    {
        return "Ingrese el nombre de la empresa o el nombre del empleado de la especialidad";  
    }else{
        $db = new conexion();
        
        $id_empleado = obtenerCodigoEmpleado($nombre_emp,$apellido_emp,$nombre_especialidad);
        $id_instituto = obtenerCodigoInstitutoSalud($nombre_instituto);
                
        $sql = "select id from empleado_instituto where id_empleado=$id_empleado and id_instituto_salud=$id_instituto";
       
        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_empleado_instituto=$fila[0];
        
        return $id_empleado_instituto;
    } 
 
}

function agregarEmpleadoInstituto($id_instituto_salud,$id_empleado) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO empleado_instituto(id_instituto_salud,id_empleado,estado)";
    $sql.=" VALUES($id_instituto_salud,$id_empleado,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Empleado por Instituto";
    } else 
    {
        return "Se Guardo el Empleado por Instituto exitosamente";
    }
}

function modificaEmpleadoInstituto($id_empleado_instituto,$id_instituto_salud,$id_empleado,$estado) {
    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" id_instituto_salud=$id_instituto_salud,id_empleado=$id_empleado,estado='$estado'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Empleado_Instituto";
    }else{
        return "Se Modifico el Empleado_Instituto exitosamente";
    }
}
               
function eliminaEmpleadoInstitutoPorNombre($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto) {

    $id_empleado_instituto=obtenerCodigoEmpleadoInstituto($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto);
    
    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino Empleado por Instituto";
    }else{
        return "Se Elimino Empleado por Instituto exitosamente";
    }
}

function eliminaEmpleadoporInstituto($id_empleado_instituto) {

    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino Empleado por Instituto";
    }else{
        return "Se Elimino Empleado por Instituto exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Nivel Instrucción

function listaNivelInstruccion() {
    
    $sql = "select * from nivel_instruccion";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaNivelInstruccionPorNombre($nombre_nivel_instruccion) {
    
    if($nombre_nivel_instruccion=='')
    {
        return "Ingrese Nivel Instruccion";   
    }else{
        
        $sql = "select * from nivel_instruccion where nombre='$nombre_nivel_instruccion'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaNivelInstruccionPorId($id_nivel_instruccion) {
    
    if($id_nivel_instruccion=='')
    {
        return "Ingrese el codigo nivel_instruccion";   
    }else{
        
        $sql = "select * from nivel_instruccion where id=$id_nivel_instruccion";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoNivelInstruccion($nombre_nivel_instruccion){
    
    if($nombre_nivel_instruccion=='')
    {
        return "Ingrese el nivel_instruccion";  
    }else{
        $db = new conexion();
        $sql2 = "select id from nivel_instruccion where nombre = '$nombre_nivel_instruccion'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_nivel_instruccion=$fila[0];
        
        return $id_nivel_instruccion;
    } 
 
}

function agregarNivelInstruccion($nombre_nivel_instruccion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO nivel_instruccion(nombre)";
    $sql.=" VALUES('$nombre_nivel_instruccion')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo nivel_instruccion";
    } else 
    {
        return "Se Guardo  exitosamente";
    }
}

function modificaNivelInstruccion($id_nivel_instruccion,$nombre_nivel_instruccion) {
    $sql ="update nivel_instruccion ";
    $sql.="set";
    $sql.=" nombre='$nombre_nivel_instruccion'";
    $sql.=" where id=$id_nivel_instruccion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se modifico nivel_instruccion";
    }else{
        return "Se Modifico exitosamente";
    }
}
               
function eliminaNivelInstruccionPorNombre($nombre_nivel_instruccion) {

    $id_nivel_instruccion=obtenerCodigoNivelInstruccion($nombre_nivel_instruccion);
    
    $sql="delete from nivel_instruccion ";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_nivel_instruccion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino ";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaNivelInstruccion($id_nivel_instruccion) {

    $sql ="delete from nivel_instruccion ";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_nivel_instruccion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino nivel instruccion";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Religión

function listaReligion() {
    
    $sql = "select * from religion where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaReligionPorNombre($nombre_religion) {
    
    if($nombre_religion=='')
    {
        return "Ingrese Religion";   
    }else{
        
        $sql = "select * from religion where nombre='$nombre_religion'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaReligionPorId($id_religion) {
    
    if($id_religion=='')
    {
        return "Ingrese el codigo de religion";   
    }else{    
        $sql = "select * from religion where id=$id_religion";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoReligion($nombre_religion){
    
    if($nombre_religion=='')
    {
        return "Ingrese el nombre de religion";  
    }else{
        $db = new conexion();
        $sql2 = "select id from religion where nombre = '$nombre_religion'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_religion=$fila[0];
        
        return $id_religion;
    } 
 
}

function agregarReligion($nombre_religion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO religion(nombre,estado)";
    $sql.=" VALUES('$nombre_religion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo Religion";
    } else 
    {
        return "Se Guardo  exitosamente";
    }
}

function modificaReligion($id_religion,$nombre_religion,$estado) {
    $sql ="update religion ";
    $sql.="set";
    $sql.=" nombre='$nombre_religion',estado='$estado'";
    $sql.=" where id=$id_religion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico Religion";
    }else{
        return "Se Modifico exitosamente";
    }
}
               
function eliminaReligionPorNombre($nombre_religion) {

    $id_religion=obtenerCodigoReligion($nombre_religion);
    
    $sql ="update religion ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_religion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino ";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaReligion($id_religion) {

    $sql ="update religion ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_religion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino religion";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Grupo_Sanguineo

function listaGrupoSanguineo() {
    
    $sql = "select * from grupo_sanguineo";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaGrupoSanguineoPorNombre($nombre_grupo_sanguineo) {
    
    if($nombre_grupo_sanguineo=='')
    {
        return "Ingrese el grupo sanguineo";   
    }else{
        
        $sql = "select * from grupo_sanguineo where nombre='$nombre_grupo_sanguineo'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaGrupoSanguineoPorId($id_grupo_sanguineo) {
    
    if($id_grupo_sanguineo=='')
    {
        return "Ingrese el codigo grupo_sanguineo";   
    }else{
        
        $sql = "select * from grupo_sanguineo where id=$id_grupo_sanguineo";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoGrupoSanguineo($nombre_grupo_sanguineo){
    
    if($nombre_grupo_sanguineo=='')
    {
        return "Ingrese el nombre grupo sanguineo";  
    }else{
        $db = new conexion();
        $sql2 = "select id from grupo_sanguineo where nombre = '$nombre_grupo_sanguineo'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_grupo_sanguineo=$fila[0];
        
        return $id_grupo_sanguineo;
    } 
}

function agregarGrupoSanguineo($nombre) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO grupo_sanguineo(nombre)";
    $sql.=" VALUES('$nombre')";
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Grupo Sanguineo";
    } else 
    {
        return "Se Guardo el Grupo Sanguineo";
    }
}

function modificaGrupoSanguineo($id_grupo_sanguineo,$nombre) {
    $sql ="update grupo_sanguineo ";
    $sql.="set";
    $sql.=" nombre='$nombre'";
    $sql.=" where id=$id_grupo_sanguineo";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Grupo Sanguineo";
    }else{
        return "Se Modifico el Grupo Sanguineo exitosamente";
    }
}

function eliminaGrupoSanguineoPorNombre($nombre_grupo_sanguineo) {

    $id_grupo_sanguineo=obtenerCodigoGrupoSanguineo($nombre_grupo_sanguineo);
    
    $sql="delete from grupo_sanguineo";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_grupo_sanguineo";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino ";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaGrupoSanguineo($id_grupo_sanguineo) {

    $sql="delete from grupo_sanguineo";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_grupo_sanguineo";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Estado_Civil

function listaEstadoCivil() {
    
    $sql = "select * from estado_civil";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEstadoCivilPorNombre($nombre_estado_civil) {
    
    if($nombre_estado_civil=='')
    {
        return "Ingrese Estado Civil";   
    }else{
        
        $sql = "select * from estado_civil where nombre='$nombre_estado_civil'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEstadoCivilPorId($id_estado_civil) {
    
    if($id_estado_civil=='')
    {
        return "Ingrese el codigo estado_civil";   
    }else{
        
        $sql = "select * from estado_civil where id=$id_estado_civil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEstadoCivil($nombre_estado_civil){
    
    if($nombre_estado_civil=='')
    {
        return "Ingrese el nombre estado civil";  
    }else{
        $db = new conexion();
        $sql2 = "select id from estado_civil where nombre = '$nombre_estado_civil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_estado_civil=$fila[0];
        
        return $id_estado_civil;
    } 
}

function agregarEstadoCivil($nombre) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO estado_civil(nombre)";
    $sql.=" VALUES('$nombre')";
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Estado Civil";
    } else 
    {
        return "Se Guardo el Estado Civil";
    }
}

function modificaEstadoCivil($id_estado_civil,$nombre) {
    $sql ="update estado_civil ";
    $sql.="set";
    $sql.=" nombre='$nombre'";
    $sql.=" where id=$id_estado_civil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el estado civil";
    }else{
        return "Se Modifico el estado civil exitosamente";
    }
}

function eliminaEstadoCivilPorNombre($nombre_estado_civil) {

    $id_estado_civil=obtenerCodigoEstadoCivil($nombre_estado_civil);
    
    $sql="delete from estado_civil";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_estado_civil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino ";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaEstadoCivil($id_estado_civil) {

    $sql="delete from estado_civil";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_estado_civil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Etnia

function listaEtnia() {
    
    $sql = "select * from etnia";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEtniaPorNombre($nombre_etnia) {
    
    if($nombre_etnia=='')
    {
        return "Ingrese el nombre de la etnia";   
    }else{
        
        $sql = "select * from etnia where nombre='$nombre_etnia'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEtniaPorId($id_etnia) {
    
    if($id_etnia=='')
    {
        return "Ingrese el codigo etnia";   
    }else{
        
        $sql = "select * from etnia where id=$id_etnia";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEtnia($nombre_etnia){
    
    if($nombre_etnia=='')
    {
        return "Ingrese el nombre de la etnia";  
    }else{
        $db = new conexion();
        $sql2 = "select id from etnia where nombre='$nombre_etnia'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_etnia=$fila[0];
        
        return $id_etnia;
    } 
}

function agregarEtnia($nombre) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO etnia(nombre)";
    $sql.=" VALUES('$nombre')";
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Etnia";
    } else 
    {
        return "Se Guardo la Etnia";
    }
}

function modificaEtnia($id_etnia,$nombre) {
    $sql ="update etnia ";
    $sql.="set";
    $sql.=" nombre='$nombre'";
    $sql.=" where id=$id_etnia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Etnia";
    }else{
        return "Se Modifico la Etnia exitosamente";
    }
}

function eliminaEtniaPorNombre($nombre_etnia) {

    $id_etnia=obtenerCodigoEtnia($nombre_etnia);
    
    $sql="delete from etnia";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_etnia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino ";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaEtnia($id_etnia) {

    $sql="delete from etnia";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_etnia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Direccion

function listaDireccion() {
    
    $sql ="select d.id,p.cedula,p.nombre,p.apellido,d.direccion_residencia,d.direccion_trabajo";
    $sql.=" from direccion d,persona p where d.id_persona=p.id and d.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaDireccionPorCedula($cedula) {
    
    $sql ="select d.id,p.nombre,p.apellido,d.direccion_residencia,d.direccion_trabajo";
    $sql.=" from direccion d,persona p where d.id_persona=p.id and d.estado='Activo'";
    $sql.=" and p.cedula='$cedula'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoDireccion($cedula,$direccion_residencia){
    
    if($cedula=='')
    {
        return "Ingrese el nombre de la cedula de la persona";  
    }else{
        $db = new conexion();
        
        $sql2 ="select d.id from direccion d,persona p where d.id_persona=p.id";
        $sql2.=" and p.cedula='$cedula' and d.direccion_residencia='$direccion_residencia'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_etnia=$fila[0];
        
        return $id_etnia;
    } 
}

function agregarDireccion($id_persona,$direccion_residencia, $direccion_trabajo) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO direccion(id_persona,direccion_residencia,direccion_trabajo,estado)";
    $sql.=" VALUES($id_persona,'$direccion_residencia','$direccion_trabajo','Activo')";
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la direccion";
    } else 
    {
        return "Se Guardo la direccion exitosamente";
    }
}

function modificaDireccion($id_direccion,$id_persona,$direccion_residencia,$direccion_trabajo,$estado) {
    $sql ="update direccion ";
    $sql.="set";
    $sql.=" id_persona=$id_persona,direccion_residencia='$direccion_residencia',direccion_trabajo='$direccion_trabajo',estado='$estado'";
    $sql.=" where id=$id_direccion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la direccion";
    }else{
        return "Se Modifico la direccion exitosamente";
    }
}

function eliminaDireccion($id_direccion) {

    $sql ="update direccion";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_direccion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la direccion";
    }else{
        return "Se Elimino la direccion exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Telefono

function listaTelefono() {
    
    $sql ="select t.id,p.cedula,p.nombre,p.apellido,t.telefono_fijo,t.telefono_movil";
    $sql.=" from telefono t,persona p where t.id_persona=p.id and t.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaTelefonoPorCedula($cedula) {
    
    $sql ="select t.id,p.nombre,p.apellido,t.telefono_fijo,t.telefono_movil";
    $sql.=" from telefono t,persona p where t.id_persona=p.id and t.estado='Activo'";
    $sql.=" and p.cedula='$cedula'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoTelefono($cedula,$telefono_movil){
    
    if($cedula=='')
    {
        return "Ingrese el nombre de la cedula de la persona";  
    }else{
        $db = new conexion();
        
        $sql2 ="select t.id from telefono t,persona p where t.id_persona=p.id";
        $sql2.=" and p.cedula='$cedula' and t.telefono_movil='$telefono_movil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_etnia=$fila[0];
        
        return $id_etnia;
    } 
}

function agregarTelefono($id_persona,$id_direccion,$telefono_fijo, $telefono_movil) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO telefono(id_persona,id_direccion,telefono_fijo,telefono_movil,estado)";
    $sql.=" VALUES($id_persona,$id_direccion,'$telefono_fijo','$telefono_movil','Activo')";
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el telefono";
    } else 
    {
        return "Se Guardo el telefono exitosamente";
    }
}

function modificaTelefono($id_telefono,$id_persona,$id_direccion,$telefono_fijo,$telefono_movil,$estado) {
    $sql ="update telefono ";
    $sql.="set";
    $sql.=" id_persona=$id_persona,id_direccion=$id_direccion,telefono_fijo='$telefono_fijo',telefono_movil='$telefono_movil',estado='$estado'";
    $sql.=" where id=$id_telefono";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la direccion";
    }else{
        return "Se Modifico la direccion exitosamente";
    }
}

function eliminaTelefono($id_telefono) {

    $sql ="update telefono";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_telefono";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el telefono";
    }else{
        return "Se Elimino el telefono exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Persona

function listaPersona() {
    
    $sql ="select p.id,p.cedula,p.nombre,p.apellido,p.fecha_nacimiento,p.genero,p.ocupacion,p.correo,";
    $sql.=" p.num_hijos,c.nombre,pro.nombre,n.nombre,r.nombre,es.nombre,et.nombre";
    $sql.=" from persona p,ciudad c,provincia pro,nivel_instruccion n,religion r,estado_civil es,etnia et";
    $sql.=" where p.id_ciudad_nacimiento=c.id and c.id_provincia=p.id and p.id_nivel_instruccion=n.id";
    $sql.=" and p.id_religion=r.id and p.id_estado_civil=es.id and p.id_etnia=et.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";

        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";

        $datos.= $filas[7];
        $datos.="#";
        
        $datos.= $filas[8];
        $datos.="#";
        
        $datos.= $filas[9];
        $datos.="#";
        
        $datos.= $filas[10];
        $datos.="#";

        $datos.= $filas[11];
        $datos.="#";

        $datos.= $filas[12];
        $datos.="#";

        $datos.= $filas[13];
        $datos.="#";
        
        $datos.= $filas[14];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPersonaPorCedula($cedula) {
    
    $sql ="select p.id,p.nombre,p.apellido,p.fecha_nacimiento,p.genero,p.ocupacion,p.correo,";
    $sql.=" p.num_hijos,c.nombre,pro.nombre,n.nombre,r.nombre,es.nombre,et.nombre";
    $sql.=" from persona p,ciudad c,provincia pro,nivel_instruccion n,religion r,estado_civil es,etnia et";
    $sql.=" where p.cedula='$cedula' and p.id_ciudad_nacimiento=c.id and c.id_provincia=p.id and p.id_nivel_instruccion=n.id";
    $sql.=" and p.id_religion=r.id and p.id_estado_civil=es.id and p.id_etnia=et.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";

        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";

        $datos.= $filas[7];
        $datos.="#";
        
        $datos.= $filas[8];
        $datos.="#";
        
        $datos.= $filas[9];
        $datos.="#";
        
        $datos.= $filas[10];
        $datos.="#";

        $datos.= $filas[11];
        $datos.="#";

        $datos.= $filas[12];
        $datos.="#";

        $datos.= $filas[13];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPersonaPorCedula($cedula){
    
    if($cedula=='')
    {
        return "Ingrese el nombre de la cedula de la persona";  
    }else{
        $db = new conexion();
        
        $sql2 ="select id from persona where cedula='$cedula'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_persona=$fila[0];
        
        return $id_persona;
    } 
}

function obtenerCodigoPersonaPorIdUsuario($id_usuario){
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo usuario";  
    }else{
        $db = new conexion();
        
        $sql2 ="select id from persona where id_usuario=$id_usuario";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_persona=$fila[0];
        
        return $id_persona;
    } 
}

function agregarPersona($cedula, $nombre, $apellido, $fecha_nac, $genero, $ocupacion, $correo, $num_hijos, $id_usuario,
        $id_ciudad_nacimiento,$id_nivel_instruccion,$id_religion, $id_estado_civil, $id_etnia) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO persona(cedula,nombre,apellido,fecha_nacimiento,genero,ocupacion,";
    $sql.=" correo,num_hijos,id_usuario,id_ciudad_nacimiento,id_nivel_instruccion,id_religion,";
    $sql.=" id_estado_civil,id_etnia)";
               
    $sql.=" VALUES('$cedula','$nombre','$apellido','$fecha_nac','$genero','$ocupacion','$correo',";
    $sql.="$num_hijos,$id_usuario,$id_ciudad_nacimiento,$id_nivel_instruccion,$id_religion,$id_estado_civil,$id_etnia)";
        
    
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la persona";
    } else 
    {
        return "Se Guardo la persona exitosamente";
    }
}

function modificaPersona($id_persona,$cedula, $nombre, $apellido, $fecha_nac, $genero, $ocupacion, $correo, $num_hijos, $id_usuario,
        $id_ciudad_nacimiento,$id_nivel_instruccion,$id_religion, $id_estado_civil, $id_etnia)
{
    $sql ="update persona ";
    $sql.="set";
    $sql.=" cedula='$cedula',nombre='$nombre',apellido='$apellido',fecha_nacimiento='$fecha_nac',genero='$genero',ocupacion='$ocupacion',";
    $sql.="correo='$correo',num_hijos=$num_hijos,id_usuario=$id_usuario,id_ciudad_nacimiento=$id_ciudad_nacimiento,";
    $sql.="id_nivel_instruccion=$id_nivel_instruccion,id_religion=$id_religion,";
    $sql.="id_estado_civil=$id_estado_civil,id_etnia=$id_etnia";
    $sql.=" where id=$id_persona";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la persona";
    }else{
        return "Se Modifico la persona exitosamente";
    }
}

function eliminaPersonaPorCedula($cedula) {

    $id_persona= obtenerCodigoPersonaPorCedula($cedula);
    
    $sql="delete from persona";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_persona";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino";
    }else{
        return "Se Elimino exitosamente";
    }
}

function eliminaPersona($id_persona) {

    $sql="delete from persona";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_persona";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino";
    }else{
        return "Se Elimino exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Paciente

function listaPaciente() {
    
    $sql ="select pa.id,p.cedula,p.nombre,p.apellido,p.fecha_nacimiento,p.genero,p.ocupacion,p.correo,";
    $sql.="p.num_hijos,c.nombre,pro.nombre,n.nombre,r.nombre,es.nombre,et.nombre,g.nombre";
    $sql.=" from paciente pa,persona p,ciudad c,provincia pro,nivel_instruccion n,religion r,estado_civil es,etnia et,grupo_sanguineo g";
    $sql.=" where pa.id_persona=p.id and pa.id_grupo_sanguineo=g.id and p.id_ciudad_nacimiento=c.id and c.id_provincia=p.id and p.id_nivel_instruccion=n.id";
    $sql.=" and p.id_religion=r.id and p.id_estado_civil=es.id and p.id_etnia=et.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";

        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";

        $datos.= $filas[7];
        $datos.="#";
        
        $datos.= $filas[8];
        $datos.="#";
        
        $datos.= $filas[9];
        $datos.="#";
        
        $datos.= $filas[10];
        $datos.="#";

        $datos.= $filas[11];
        $datos.="#";

        $datos.= $filas[12];
        $datos.="#";

        $datos.= $filas[13];
        $datos.="#";
        
        $datos.= $filas[14];
        $datos.="#";
        
        $datos.= $filas[15];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPacientePorCedula($cedula) {
    
    if($cedula=='')
    {
        return "Ingrese la cedula";   
    }else{
        
        $sql ="select pa.id,p.nombre,p.apellido,p.fecha_nacimiento,p.genero,p.ocupacion,p.correo,";
        $sql.="p.num_hijos,c.nombre,pro.nombre,n.nombre,r.nombre,es.nombre,et.nombre,g.nombre";
        $sql.=" from paciente pa,persona p,ciudad c,provincia pro,nivel_instruccion n,religion r,estado_civil es,etnia et,grupo_sanguineo g";
        $sql.=" where pa.id_persona=p.id and pa.id_grupo_sanguineo=g.id and p.cedula='$cedula' and p.id_ciudad_nacimiento=c.id and c.id_provincia=p.id and p.id_nivel_instruccion=n.id";
        $sql.=" and p.id_religion=r.id and p.id_estado_civil=es.id and p.id_etnia=et.id";
        
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";

        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";

        $datos.= $filas[7];
        $datos.="#";
        
        $datos.= $filas[8];
        $datos.="#";
        
        $datos.= $filas[9];
        $datos.="#";
        
        $datos.= $filas[10];
        $datos.="#";

        $datos.= $filas[11];
        $datos.="#";

        $datos.= $filas[12];
        $datos.="#";

        $datos.= $filas[13];
        $datos.="#";
        
        $datos.= $filas[14];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPacientePorIdPersona($id_persona) {
    
    if($id_paciente=='')
    {
        return "Ingrese el id del paciente";   
    }else{
        
        $sql ="select p.cedula,p.nombre,p.apellido,p.fecha_nacimiento,p.genero,p.ocupacion,p.correo,";
        $sql.="p.num_hijos,c.nombre,pro.nombre,n.nombre,r.nombre,es.nombre,et.nombre,g.nombre";
        $sql.=" from paciente pa,persona p,ciudad c,provincia pro,nivel_instruccion n,religion r,estado_civil es,etnia et,grupo_sanguineo g";
        $sql.=" where pa.id_persona=$id_persona and pa.id_persona=p.id and pa.id_grupo_sanguineo=g.id and p.id_ciudad_nacimiento=c.id and c.id_provincia=p.id and p.id_nivel_instruccion=n.id";
        $sql.=" and p.id_religion=r.id and p.id_estado_civil=es.id and p.id_etnia=et.id";
        
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

         $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";

        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";

        $datos.= $filas[7];
        $datos.="#";
        
        $datos.= $filas[8];
        $datos.="#";
        
        $datos.= $filas[9];
        $datos.="#";
        
        $datos.= $filas[10];
        $datos.="#";

        $datos.= $filas[11];
        $datos.="#";

        $datos.= $filas[12];
        $datos.="#";

        $datos.= $filas[13];
        $datos.="#";
        
        $datos.= $filas[14];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPaciente($cedula){
    
    if($cedula=='')
    {
        return "Ingrese la cedula";  
    }else{
        $db = new conexion();
       
        $sql ="select pa.id from paciente pa,persona p";
        $sql.=" where pa.id_persona=p.id and";
        $sql.=" p.cedula ='$cedula'";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_paciente=$fila[0];
        
        return $id_paciente;
    } 
 
}

function agregarPaciente($id_persona,$id_grupo_sanguineo) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO paciente(id_persona,id_grupo_sanguineo)";
    $sql.=" VALUES($id_persona,$id_grupo_sanguineo)";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Paciente";
    } else 
    {
        return "Se Guardo el paciente exitosamente";
    }
}

function modificaPaciente($id_paciente,$id_persona,$id_grupo_sanguineo) {
    $sql ="update paciente ";
    $sql.="set";
    $sql.=" id_persona=$id_persona,id_grupo_sanguineo= $id_grupo_sanguineo";
    $sql.=" where id=$id_paciente";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el paciente";
    }else{
        return "Se Modifico el paciente exitosamente";
    }
}
               
function eliminaPacientePorCedula($cedula) { 

    $id_paciente=obtenerCodigoPaciente($cedula);
    
    $sql = "delete from paciente ";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_paciente";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Paciente";
    }else{
        return "Se Elimino el Paciente exitosamente";
    }
}

function eliminaPaciente($id_paciente) {

    $sql = "delete from paciente ";
    //$sql.="set";
    //$sql.= " estado='Inactivo'";
    $sql.=" where id=$id_paciente";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Paciente";
    }else{
        return "Se Elimino el Paciente exitosamente";
    }
}