<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
error_reporting("E_ALL");
ini_set("display_errors", 1);
if (isset($HTTP_RAW_POST_DATA)) {
    $input = $HTTP_RAW_POST_DATA;
} else {
    $input = implode("\r\n", file('php://input'));
}
require_once('../lib/nusoap-0.9.5/lib/nusoap.php');
require('../modelo/shc.php');

$server = new soap_server;
$ns = "http://localhost/SHC_Servicio/vista/servicio_web.php";
$server->configurewsdl('Servicio_Web', $ns);


/*listaPerfil
listaPerfilPorId
listaPerfilPorNombre($nombre_perfil)
listaPerfilPorId($id_perfil)
obtenerCodigoPerfil($nombre_perfil)
agregarPerfil($nombre)
modificaPerfil($id_perfil,$nombre,$estado)
eliminaPerfilPorNombre($nombre_perfil)
eliminaPerfil($nombre_perfil)*/
        
/// Perfil

//Lista de Perfil
$server->register("listaPerfil", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Nombre
$server->register("listaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil por Id
$server->register("listaPerfilPorId", array(
'id_Perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código perfil
$server->register("obtenerCodigoPerfil", array(
'nombre_perfil' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil 
$server->register("agregarPerfil", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil 
$server->register("modificaPerfil", array(
'id_perfil' => 'xsd:int',
'nombre' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil por Nombre
$server->register("eliminaPerfilPorNombre", array(
'nombre_perfil' => 'xsd:nombre',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil
$server->register("eliminaPerfil", array(
'id_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista de Opcion
$server->register("listaOpcion", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion por Nombre
$server->register("listaOpcionPorNombre", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion por Id
$server->register("listaOpcionPorId", array(
'id_opcion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Opcion
$server->register("obtenerCodigoOpcion", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Agregar Opcion
$server->register("agregarOpcion", array(
'nombre_opcion' => 'xsd:string',
'url_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Opcion
$server->register("modificaOpcion", array(
'id_opcion' => 'xsd:int',
'nombre_opcion' => 'xsd:string',
'url_opcion' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion por Nombre
$server->register("eliminaOpcionPorNombre", array(
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion
$server->register("eliminaOpcion", array(
'id_opcion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista Opcion Perfil
$server->register("listaOpcionPerfil", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Opcion Perfil por Id
$server->register("listaOpcionPerfilPorId", array(
'id_opcion_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);
        
//Obtener Código Opcion Perfil
$server->register("obtenerCodigoOpcionPerfil", array(
'nombre_perfil' => 'xsd:string',
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Opcion Perfil
$server->register("agregarOpcionPerfil", array(
'nombre_perfil' => 'xsd:string',
'nombre_opcion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Opcion Perfil  
$server->register("modificaOpcionPerfil", array(
'id_opcion_perfil' => 'xsd:int',
'id_opcion' => 'xsd:int',
'id_perfil' => 'xsd:int',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Opcion Perfil
$server->register("eliminaOpcionPerfil", array(
'id_opcion_perfil' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista de Usuario
$server->register("listaUsuario", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Usuario por Id
$server->register("listaUsuarioPorId", array(
'id_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código usuario
$server->register("obtenerCodigoUsuario", array(
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Usuario
$server->register("agregarUsuario", array(
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Usuario 
$server->register("modificaUsuario", array(
'id_usuario' => 'xsd:int',
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Usuario por Nombre
$server->register("eliminaUsuarioPorNombre", array(
'nombre_usuario' => 'xsd:string',
'clave_usuario' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Usuario
$server->register("eliminaUsuario", array(
'id_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista Perfil Usuario
$server->register("listaPerfilUsuario", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Perfil Usuario por Id
$server->register("listaPerfilUsuarioPorId", array(
'id_Perfil_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Perfil Usuario
$server->register("obtenerCodigoPerfilUsuario", array(
'nombre_perfil' => 'xsd:string',
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//Agregar Perfil Usuario
$server->register("agregarPerfilUsuario", array(
'nombre_perfil' => 'xsd:string',
'usuario' => 'xsd:string',
'clave' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Perfil Usuario 
$server->register("modificaPerfilUsuario", array(
'id_perfil_usuario' => 'xsd:int',
'id_usuario' => 'xsd:int',
'id_perfil' => 'xsd:int',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Perfil Usuario
$server->register("eliminaPerfilUsuario", array(
'id_perfil_usuario' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////

//Lista de Provincia
$server->register("listaProvincia", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Provincia por Nombre
$server->register("listaProvinciaPorNombre", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Provincia por Id
$server->register("listaProvinciaPorId", array(
'id_provincia' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Provincia
$server->register("obtenerCodigoProvincia", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Agregar Provincia
$server->register("agregarProvincia", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Provincia
$server->register("modificaProvincia", array(
'id_provincia' => 'xsd:int',
'nombre_provincia' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Provincia por Nombre
$server->register("eliminaProvinciaPorNombre", array(
'nombre_provincia' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Provincia
$server->register("eliminaProvincia", array(
'id_provincia' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);


///////////////////////////////////////////////////////////

//Lista de Ciudad
$server->register("listaCiudad", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Ciudad por Nombre
$server->register("listaCiudadPorNombre", array(
'nombre_ciudad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Ciudad por Id
$server->register("listaCiudadPorId", array(
'id_ciudad' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Ciudad
$server->register("obtenerCodigoCiudad", array(
'nombre_provincia' => 'xsd:string',
'nombre_ciudad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Agregar Ciudad
$server->register("agregarCiudad", array(
'nombre_provincia' => 'xsd:string',
'nombre_ciudad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Ciudad
$server->register("modificaCiudad", array(
'id_ciudad' => 'xsd:int',
'id_provincia' => 'xsd:int',
'nombre_ciudad' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Ciudad por Nombre
$server->register("eliminaCiudadPorNombre", array(
'nombre_provincia' => 'xsd:string',
'nombre_ciudad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Ciudad
$server->register("eliminaCiudad", array(
'id_ciudad' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////
/// Instituto Salud

//Lista de Instituto
$server->register("listaInstitutoSalud", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//listaInstitutoSaludPorNombre
$server->register("listaInstitutoSaludPorNombre", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Instituto Salud por Id
$server->register("listaInstitutoSaludPorId", array(
'id_instituto_salud' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//obtenerCodigoInstitutoSalud
$server->register("obtenerCodigoInstitutoSalud", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//agregarInstitutoSalud
$server->register("agregarInstitutoSalud", array(
'ruc' => 'xsd:int',
'razon_social' => 'xsd:string',
'nombre' => 'xsd:string',
'id_ciudad' => 'xsd:int',
'direccion' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//modificaInstituoSalud 
$server->register("modificaInstitutoSalud", array(
'id_instituto_salud' => 'xsd:int',
'ruc' => 'xsd:int',
'razon_social' => 'xsd:string',
'nombre' => 'xsd:string',
'id_ciudad' => 'xsd:int',
'direccion' => 'xsd:string',
'estado'=> 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaInstitutoSaludPorNombre
$server->register("eliminaInstitutoSaludPorNombre", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaInstitutoSalud
$server->register("eliminaInstitutoSalud", array(
'id_instituto_salud' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////
/// Especialidad

//Lista de Especialidad
$server->register("listaEspecialidad", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//listaEspecialidadporNombre
$server->register("listaEspecialidadPorNombre", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//listaEspecialidadPorId
$server->register("listaEspecialidadPorId", array(
'id_especialidad' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//obtenerCodigoEspecialidad
$server->register("obtenerCodigoEspecialidad", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//agregarEspecialidad
$server->register("agregarEspecialidad", array(
'nombre' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);

//modificaEspecialidad
$server->register("modificaEspecialidad", array(
'id_especialidad' => 'xsd:int',
'nombre' => 'xsd:string',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaEspecialidadPorNombre
$server->register("eliminaEspecialidadPorNombre", array(
'nombre'=> 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaEspecialidad
$server->register("eliminaEspecialidad", array(
'id_especialidad' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////
//Empleado

//Lista de Empleado
$server->register("listaEmpleado", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//Lista Empleado por Especialidad
$server->register("listaEmpleadoPorEspecialidad", array(
'especialidad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Lista Empleado por Id
$server->register("listaEmpleadoPorId", array(
'id_empleado' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Obtener Código Empleado
$server->register("obtenerCodigoEmpleado", array(
'nombre' => 'xsd:string',
'apellido' => 'xsd:string',
'especialidad' => 'xsd:string',
), array('Respuesta' => 'xsd:int'), $ns);
 
//Agregar Empleado
$server->register("agregarEmpleado", array(
'id_persona' => 'xsd:int',
'id_especialidad' => 'xsd:int',
'id_nivel_instruccion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Modifica Empleado 
$server->register("modificaEmpleado", array(
'id_empleado' => 'xsd:int',
'id_especialidad' => 'xsd:int',
'id_nivel_instruccion' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Empleado por Nombre
$server->register("eliminaEmpleadoPorNombre", array(
'nombre' => 'xsd:string',
'apellido' => 'xsd:string',
'especialidad' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//Elimina Empleado
$server->register("eliminaEmpleado", array(
'id_empleado' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

///////////////////////////////////////////////////////////
//Empleado_Instituto

//listaEmpleadoPorInstituto
$server->register("listaEmpleadoInstituto", array(),
            array('Respuesta' => 'xsd:string'), $ns);

//listaEmpleadosPorInstituto
$server->register("listaEmpleadosporInstituto", array(
'nombre_instituto' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//listaEmpleadosPorId
$server->register("listaEmpleadoInstitutoPorId", array(
'id_empleado_instituto' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

//obtenerCodigoEmpleadoInstituto
$server->register("obtenerCodigoEmpleadoInstituto", array(
'nombre_emp' => 'xsd:string',
'apellido_emp' => 'xsd:string',
'nombre_especialidad' => 'xsd:string',
'nombre_instituto' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//agregarEmpleadoInstituto
$server->register("agregarEmpleadoInstituto", array(
'id_instituto_salud' => 'xsd:int',
'id_empleado' => 'xsd:int',
), array('Respuesta' => 'xsd:int'), $ns);

//modificaEmpleadoInstituto
$server->register("modificaEmpleadoInstituto", array(
'id_empleado_instituto' => 'xsd:int',
'id_instituto_salud' => 'xsd:int',
'id_empleado' => 'xsd:int',
'estado' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaEmpleadoInstitutoPorNombre
$server->register("eliminaEmpleadoInstitutoPorNombre", array(
'nombre_emp' => 'xsd:string',
'apellido_emp' => 'xsd:string',
'nombre_especialidad' => 'xsd:string',
'nombre_instituto' => 'xsd:string',
), array('Respuesta' => 'xsd:string'), $ns);

//eliminaEmpleadoporInstituto
$server->register("eliminaEmpleadoporInstituto", array(
'id_empleado_instituto' => 'xsd:int',
), array('Respuesta' => 'xsd:string'), $ns);

$server->service($HTTP_RAW_POST_DATA);

