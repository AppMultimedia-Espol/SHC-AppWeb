<?php
include($_SERVER["DOCUMENT_ROOT"] . '/SHC_Servicio/db/Conexion.class.php');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of shc
 *
 * @author Grupo Servicios Web
 */

function listaPerfil() {
    
    $sql = "select * from perfil where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorNombre($nombre_perfil) {
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";   
    }else{
        
        $sql = "select * from perfil where nombre='$nombre_perfil'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaPerfilPorId($id_perfil) {
    
    if($id_perfil=='')
    {
        return "Ingrese el codigo del perfil";   
    }else{
        
        $sql = "select * from perfil where id=$id_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfil($nombre_perfil){
    
    if($nombre_perfil=='')
    {
        return "Ingrese el nombre del perfil";  
    }else{
        $db = new conexion();
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];
        
        return $id_perfil;
    } 
 
}

function agregarPerfil($nombre) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO perfil(nombre,estado)";
    $sql.=" VALUES('$nombre','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil";
    } else 
    {
        return "Se Guardo el Perfil exitosamente";
    }
}

function modificaPerfil($id_perfil,$nombre,$estado) {
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil";
    }else{
        return "Se Modifico el Perfil exitosamente";
    }
}
               
function eliminaPerfilPorNombre($nombre_perfil) {

    $id_perfil=obtenerCodigoPerfil($nombre_perfil);
    
    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

function eliminaPerfil($id_perfil) {

    $sql = "update perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil";
    }else{
        return "Se Elimino el Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Opcion
function listaOpcion() {
    
    $sql = "select * from opcion where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorNombre($nombre_opcion) {
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la Opcion";   
    }else{
        
        $sql = "select * from opcion where nombre='$nombre_opcion'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaOpcionPorId($id_opcion) {
    
    if($id_opcion=='')
    {
        return "Ingrese el codigo de la Opcion";   
    }else{
        
        $sql = "select * from opcion where id=$id_opcion";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcion($nombre_opcion){
    
    if($nombre_opcion=='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        $sql2 = "select id from opcion where nombre = '$nombre_opcion'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_opcion=$fila[0];
        
        return $id_opcion;
    } 
 
}

function agregarOpcion($nombre_opcion,$url_opcion) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO opcion(nombre,url,estado)";
    $sql.=" VALUES('$nombre_opcion','$url_opcion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion";
    } else 
    {
        return "Se Guardo la Opcion exitosamente";
    }
}

function modificaOpcion($id_opcion,$nombre_opcion,$url_opcion, $estado) {
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " nombre='$nombre_opcion',url='$url_opcion',estado='$estado'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion";
    }else{
        return "Se Modifico la Opcion exitosamente";
    }
}
               
function eliminaOpcionPorNombre($nombre_opcion) {

    $id_opcion=obtenerCodigoOpcion($nombre_opcion);
    
    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

function eliminaOpcion($id_opcion) {

    $sql = "update opcion ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion";
    }else{
        return "Se Elimino la Opcion exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Opcion Perfil
function listaOpcionPerfil() {
    
    $sql = "select p.nombre,o.nombre,o.url from perfil p,opcion o,opcion_perfil op";
    $sql.=" where op.id_perfil=p.id and op.id_opcion=o.id and op.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaOpcionPerfilPorId($id_opcion_perfil) {
    
    if($id_opcion_perfil=='')
    {
        return "Ingrese el codigo de la Opcion Perfil";   
    }else{
        
        $sql = "select * from opcion_perfil where id=$id_opcion_perfil";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoOpcionPerfil($nombre_perfil,$nombre_opcion){
    
    if($nombre_opcion=='' || $nombre_perfil='')
    {
        return "Ingrese el nombre de la opcion";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from opcion where nombre = '$nombre_opcion'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_opcion=$fila1[0];
        
        $sql4 = "select id from opcion_perfil where id_opcion = $id_opcion and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_opcion_perfil=$fila2[0];
        
        return $id_opcion_perfil;
    } 
 
}

function agregarOpcionPerfil($nombre_perfil,$nombre_opcion) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_opcion=$fila[0];
    
    $sql3 = "select id from opcion where nombre = '$nombre_opcion'";
     
    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_perfil=$fila1[0];
    
    $sql = "INSERT INTO opcion(id_perfil,id_opcion,estado)";
    $sql.=" VALUES($id_perfil,$id_opcion,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Opcion Perfil";
    } else 
    {
        return "Se Guardo la Opcion Perfil exitosamente";
    }
}

function modificaOpcionPerfil($id_opcion_perfil,$id_opcion,$id_perfil, $estado) {
    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " id_opcion=$id_opcion,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Opcion Perfil";
    }else{
        return "Se Modifico la Opcion Perfil exitosamente";
    }
}

function eliminaOpcionPerfil($id_opcion_perfil) {

    $sql = "update opcion_perfil ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_opcion_perfil";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Opcion Perfil";
    }else{
        return "Se Elimino la Opcion Perfil exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Usuario

function listaUsuario() {
    
    $sql = "select * from usuario where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaUsuarioPorId($id_usuario) {
    
    if($id_usuario=='')
    {
        return "Ingrese el codigo del usuario";   
    }else{
        
        $sql = "select * from usuario where id=$id_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoUsuario($usuario,$clave){
    
    if($usuario=='' || $clave=='')
    {
        return "Ingrese el nombre del usuario";  
    }else{
        $db = new conexion();
        $sql2 = "select id from usuario where usuario = '$nombre_usuario' and clave='$clave'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_usuario=$fila[0];
        
        return $id_usuario;
    } 
 
}

function agregarUsuario($nombre_usuario,$clave_usuario) 
{
    $db = new conexion(); 
    
    $sql = "INSERT INTO usuario(usuario,clave,estado)";
    $sql.=" VALUES('$nombre_usuario','$clave_usuario','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Usuario";
    } else 
    {
        return "Se Guardo el Usuario exitosamente";
    }
}

function modificaUsuario($id_usuario,$nombre_usuario,$clave_usuario,$estado) {
    $sql = "update usuario ";
    $sql.="set";
    $sql.= " usuario='$nombre_usuario',clave='$clave_usuario',estado='$estado'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Usuario";
    }else{
        return "Se Modifico el Usuario exitosamente";
    }
}
               
function eliminaUsuarioPorNombre($nombre_usuario,$clave_usuario) {

    $id_usuario=obtenerCodigoUsuario($nombre_usuario,$clave_usuario);
    
    $sql ="update usuario ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

function eliminaUsuario($id_usuario) {

    $sql = "update usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Usuario";
    }else{
        return "Se Elimino el Usuario exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Perfil Usuario
function listaPerfilUsuario() {
    
    $sql = "select u.usuario,u.clave,p.nombre from usuario u, perfil p, perfil_usuario per";
    $sql.=" where per.id_usuario= u.id and per.id_perfil=p.id and per.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";

        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}


function listaPerfilUsuarioPorId($id_perfil_usuario) {
    
    if($id_perfil_usuario=='')
    {
        return "Ingrese el codigo del perfil usuario";   
    }else{
        
        $sql = "select * from  perfil_usuario where id=$id_perfil_usuario";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoPerfilUsuario($nombre_perfil,$usuario,$clave){
    
    if($nombre_perfil=='' || $usuario='' || $clave='')
    {
        return "Ingrese el nombre perfil, el usuario y clave";  
    }else{
        $db = new conexion();
        
        $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_perfil=$fila[0];

        $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

        $total_reg1 = $db->consulta($sql3);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_usuario=$fila1[0];
        
        $sql4 = "select id from perfil_usuario where id_usuario = $id_usuario and id_perfil=$id_perfil";

        $total_reg2 = $db->consulta($sql4);
        $fila2 = mysql_fetch_array($total_reg2,MYSQL_NUM);
        $id_perfil_usuario=$fila2[0];
        
        return $id_perfil_usuario;
    } 
 
}

function agregarPerfilUsuario($nombre_perfil,$usuario,$clave) 
{
    $db = new conexion(); 
    
    $sql2 = "select id from perfil where nombre = '$nombre_perfil'";
     
    $total_reg = $db->consulta($sql2);
    $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
    $id_perfil=$fila[0];

    $sql3 = "select id from usuario where usuario= '$usuario' and clave= '$clave'";

    $total_reg1 = $db->consulta($sql3);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_usuario=$fila1[0];
        
    $sql = "INSERT INTO perfil_usuario(id_usuario, id_perfil, estado)";
    $sql.=" VALUES($id_usuario,$id_perfil,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Perfil de Usuario";
    } else 
    {
        return "Se Guardo el Perfil de Perfil de Usuario exitosamente";
    }
}

function modificaPerfilUsuario($id_perfil_usuario,$id_usuario,$id_perfil,$estado){
    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.=" id_usuario=$id_usuario,id_perfil=$id_perfil,estado='$estado'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Perfil de Usuario";
    }else{
        return "Se Modifico el Perfil de Usuario exitosamente";
    }
}
               
function eliminaPerfilUsuario($id_perfil_usuario){

    $sql = "update perfil_usuario ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_perfil_usuario";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Perfil de Usuario";
    }else{
        return "Se Elimino el Perfil de Usuario exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Provincia

function listaProvincia() {
    
    $sql = "select * from provincia where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaProvinciaPorNombre($nombre_provincia) {
    
    if($nombre_provincia=='')
    {
        return "Ingrese el nombre de la provincia";   
    }else{
        
        $sql = "select * from provincia where nombre='$nombre_provincia'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
       
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaProvinciaPorId($id_provincia) {
    
    if($id_provincia=='')
    {
        return "Ingrese el codigo de la provincia";   
    }else{
        
        $sql = "select * from provincia where id=$id_provincia";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoProvincia($nombre_provincia){
    
    if($nombre_provincia=='')
    {
        return "Ingrese el nombre de la provincia";  
    }else{
        $db = new conexion();
        $sql2 = "select id from provincia where nombre = '$nombre_provincia'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_provincia=$fila[0];
        
        return $id_provincia;
    } 
}

function agregarProvincia($nombre_provincia) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO provincia(nombre,estado)";
    $sql.=" VALUES('$nombre_provincia','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Provincia";
    }else 
    {
        return "Se Guardo la Provincia exitosamente";
    }
}

function modificaProvincia($id_provincia,$nombre_provincia,$estado) {
    $sql ="update provincia ";
    $sql.="set";
    $sql.=" nombre='$nombre_provincia',estado='$estado'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Provincia";
    }else{
        return "Se Modifico la provincia exitosamente";
    }
}
               
function eliminaProvinciaPorNombre($nombre_provincia) {

    $id_provincia=obtenerCodigoProvincia($nombre_provincia);
    
    $sql ="update provincia ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la provincia";
    }else{
        return "Se Elimino la provincia exitosamente";
    }
}

function eliminaProvincia($id_provincia) {

    $sql = "update provincia ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_provincia";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Provincia";
    }else{
        return "Se Elimino la Provincia exitosamente";
    }
}

///////////////////////////////////////////////////////////

//Ciudad

function listaCiudad() {
    
    $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
    $sql.=" where c.id_provincia=p.id and c.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaCiudadPorNombre($nombre_ciudad) {
    
    if($nombre_ciudad=='')
    {
        return "Ingrese el nombre de la ciudad";   
    }else{
        
        $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
        $sql.=" where c.id_provincia=p.id and nombre='$nombre_ciudad'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
       
    $datos.= $filas[3];
    $datos.="#";
        
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaCiudadPorId($id_ciudad) {
    
    if($id_ciudad=='')
    {
        return "Ingrese el codigo de la ciudad";   
    }else{
        
        $sql ="select c.id,p.nombre,c.nombre,c.estado from ciudad c,provincia p";
        $sql.=" where c.id_provincia=p.id and id=$id_ciudad";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoCiudad($nombre_provincia,$nombre_ciudad){
    
    if($nombre_ciudad=='')
    {
        return "Ingrese el nombre de la ciudad";  
    }else{
        $db = new conexion();
        
        $sql1="select id from provincia where nombre = '$nombre_provincia'";
        
        $total_reg1 = $db->consulta($sql1);
        $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
        $id_provincia=$fila1[0];
        
        $sql2="select * from ciudad where id_provincia=$id_provincia and nombre='$nombre_ciudad'";

        $total_reg = $db->consulta($sql2);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_ciudad=$fila[0];
        
        return $id_ciudad;
    } 
 
}

function agregarCiudad($nombre_provincia,$nombre_ciudad) 
{
    $db = new conexion(); 
    
    $sql1="select * from provincia where nombre='$nombre_provincia'";
        
    $total_reg1 = $db->consulta($sql1);
    $fila1 = mysql_fetch_array($total_reg1,MYSQL_NUM);
    $id_provincia=$fila1[0];
    
    $sql ="INSERT INTO ciudad(id_provincia,nombre,estado)";
    $sql.=" VALUES($id_provincia,'$nombre_ciudad','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo la Ciudad";
    } else 
    {
        return "Se Guardo la Ciudad exitosamente";
    }
}

function modificaCiudad($id_ciudad,$id_provincia,$nombre_ciudad,$estado) {
    $sql ="update ciudad ";
    $sql.="set";
    $sql.=" id_provincia=$id_provincia,nombre='$nombre_ciudad',estado='$estado'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico la Ciudad";
    }else{
        return "Se Modifico la Ciudad exitosamente";
    }
}
               
function eliminaCiudadPorNombre($nombre_provincia,$nombre_ciudad) {

    $id_ciudad=obtenerCodigoCiudad($nombre_provincia,$nombre_ciudad);
    
    $sql ="update ciudad ";
    $sql.="set";
    $sql.= " estado='Inactivo'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la ciudad";
    }else{
        return "Se Elimino la ciudad exitosamente";
    }
}

function eliminaCiudad($id_ciudad) {

    $sql ="update ciudad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_ciudad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Ciudad";
    }else{
        return "Se Elimino la Ciudad exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Instituto Salud
function listaInstitutoSalud() {
    
    $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre, i.direccion,i.estado";
    $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and i.estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
         $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
         $datos.= $filas[6];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaInstitutoSaludPorNombre($nombre) {
    
    if($nombre=='')
    {
        return "Ingrese la razon social";   
    }else{
        
        $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre, i.direccion,i.estado";
        $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and nombre ='$nombre'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.= $filas[4];
    $datos.="#";

    $datos.= $filas[5];
    $datos.="#";
    
    $datos.= $filas[6];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaInstitutoSaludPorId($id_instituto_salud) {
    
    if($id_instituto_salud=='')
    {
        return "Ingrese el id del instituto social";   
    }else{
        
        $sql ="select i.id,i.ruc,i.razon_social,i.nombre,c.nombre,p.nombre,i.direccion,i.estado";
        $sql.=" from instituto_salud i,ciudad c,provincia p where c.id_provincia=p.id and i.id_ciudad =c.id and id=$id_instituto_salud";

    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.= $filas[3];
    $datos.="#";
    
    $datos.= $filas[4];
    $datos.="#";

    $datos.= $filas[5];
    $datos.="#";
    
    $datos.= $filas[6];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoInstitutoSalud($nombre){
    
    if($nombre=='')
    {
        return "Ingrese el nombre del instituto salud";  
    }else{
        $db = new conexion();
        $sql = "select id from instituto_salud where nombre ='$nombre')";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_instituto_salud=$fila[0];
        
        return $id_instituto_salud;
    } 
 
}

function agregarInstitutoSalud($ruc,$razon_social,$nombre,$id_ciudad,$direccion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO instituto_salud(ruc,razon_social,nombre,id_ciudad,direccion,estado)";
    $sql.=" VALUES($ruc,'$razon_social','$nombre',$id_ciudad,'$direccion','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Instituto Salud";
    } else 
    {
        return "Se Guardo el Instituto Salud exitosamente";
    }
}

function modificaInstitutoSalud($id_instituto_salud,$ruc,$razon_social,$nombre,$id_ciudad,$direccion,$estado) {
    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" ruc=$ruc,razon_social='$razon_social',nombre='$nombre',id_ciudad=$id_ciudad,direccion='$direccion',estado='$estado'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Instituo Salud";
    }else{
        return "Se Modifico el Instituto Salud exitosamente";
    }
}
               
function eliminaInstitutoSaludPorNombre($nombre) {

    $id_instituto_salud=obtenerCodigoInstitutoSalud($nombre);
    
    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Instituto Salud";
    }else{
        return "Se Elimino el Instituto Salud exitosamente";
    }
}

function eliminaInstitutoSalud($id_instituto_salud) {

    $sql ="update instituto_salud ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_instituto_salud";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Instituto Salud";
    }else{
        return "Se Elimino el Instituto Salud exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Especialidad
function listaEspecialidad() {
    
    $sql = "select * from especialidad where estado='Activo'";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEspecialidadPorNombre($nombre) {
    
    if($nombre=='')
    {
        return "Ingrese el nombre de la especialidad";   
    }else{
        
        $sql = "select * from especialidad where nombre=$nombre";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEspecialidadPorId($id_especialidad) {
    
    if($id_especialidad=='')
    {
        return "Ingrese el id de la especialidad";   
    }else{
        
        $sql = "select * from especialidad where id=$id_especialidad";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

    $datos.= $filas[0];
    $datos.="#";

    $datos.= $filas[1];
    $datos.="#";

    $datos.= $filas[2];
    $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEspecialidad($nombre){
    
    if($nombre=='')
    {
        return "Ingrese el nombre de la especialidad";  
    }else{
        $db = new conexion();
        $sql = "select id from especialidad where nombre ='$nombre'";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_especialidad=$fila[0];
        
        return $id_especialidad;
    } 
 
}

function agregarEspecialidad($nombre) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO especialidad(nombre,estado)";
    $sql.=" VALUES('$nombre','Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Especialidad";
    } else 
    {
        return "Se Guardo el Especialidad exitosamente";
    }
}

function modificaEspecialidad($id_especialidad,$nombre,$estado){
    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" nombre='$nombre',estado='$estado'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Especialidad";
    }else{
        return "Se Modifico el Especialidad exitosamente";
    }
}
               
function eliminaEspecialidadPorNombre($nombre) {

    $id_especialidad= obtenerCodigoEspecialidad($nombre);
    
    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Especialidad";
    }else{
        return "Se Elimino la Especialidad exitosamente";
    }
}

function eliminaEspecialidad($id_especialidad) {

    $sql ="update especialidad ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_especialidad";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino la Especialidad";
    }else{
        return "Se Elimino la Especialidad exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Empleado

function listaEmpleado() {
    
    $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
    $sql.=" from empleado e,persona p,telefono t,especialidad es";
    $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoPorEspecialidad($especialidad) {
    
    if($especialidad=='')
    {
        return "Ingrese la especialidad";   
    }else{
        
        $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
        $sql.=" from empleado e,persona p,telefono t,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id and es.nombre='$especialidad'";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoPorId($id_empleado) {
    
    if($id_empleado=='')
    {
        return "Ingrese el id del empleado";   
    }else{
        $sql ="select e.id,p.nombre,p.apellido,es.nombre,t.telefono_fijo,t.telefono_movil,p.correo";
        $sql.=" from empleado e,persona p,telefono t,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and t.id_persona=p.id and e.id=$id_empleado";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.= $filas[5];
        $datos.="#";
        
        $datos.= $filas[6];
        $datos.="#";
    
        $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEmpleado($nombre,$apellido,$especialidad){
    
    if($nombre=='')
    {
        return "Ingrese el nombre del empleado";  
    }else{
        $db = new conexion();
       
        $sql ="select e.id from empleado e,persona p,especialidad es";
        $sql.=" where e.id_persona=p.id and e.id_especialidad=es.id and";
        $sql.=" p.nombre ='$nombre' and p.apellido='$apellido' and es.nombre='$especialidad'";

        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_empleado=$fila[0];
        
        return $id_empleado;
    } 
 
}

function agregarEmpleado($id_persona,$id_especialidad,$id_nivel_instruccion) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO empleado(id_persona,id_especialidad,id_nivel_instruccion)";
    $sql.=" VALUES($id_persona,$id_especialidad,$id_nivel_instruccion)";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Empleado";
    } else 
    {
        return "Se Guardo el Empleado exitosamente";
    }
}

function modificaEmpleado($id_empleado,$id_especialidad,$id_nivel_instruccion) {
    $sql ="update empleado ";
    $sql.="set";
    $sql.=" id_especialidad=$id_especialidad,id_nivel_instruccion=$id_nivel_instruccion";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Empleado";
    }else{
        return "Se Modifico el Empleado exitosamente";
    }
}
               
function eliminaEmpleadoPorNombre($nombre,$apellido,$especialidad) {

    $id_empleado=obtenerCodigoEmpleado($nombre,$apellido,$especialidad);
    
    $sql ="update empleado ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Empleado";
    }else{
        return "Se Elimino el Empleado exitosamente";
    }
}

function eliminaEmpleado($id_empleado) {

    $sql ="update empleado ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino el Empleado";
    }else{
        return "Se Elimino el Empleado exitosamente";
    }
}

///////////////////////////////////////////////////////////
//Empleado_Instituto

function listaEmpleadoInstituto() {
    
    $sql ="select ei.id,i.nombre,p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
    $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
    $sql.=" and e.id_persona=p.id and e.id_especialidad=es.id";
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
        $filas = mysql_fetch_array($resul);
        //$datos.="<elemento>";

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
        
        $datos.="@";
    }
    
    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadosporInstituto($nombre_instituto) {
    
    if($nombre_instituto=='')
    {
        return "Ingrese el id del empleado instituto";   
    }else{
        
        $sql ="select p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
        $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
        $sql.=" and i.nombre='$nombre_instituto' and e.id_persona=p.id and e.id_especialidad=es.id";
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function listaEmpleadoInstitutoPorId($id_empleado_instituto) {
    
    if($id_empleado_instituto=='')
    {
        return "Ingrese el id del empleado instituto";   
    }else{
        
        $sql ="select ei.id,i.nombre,p.nombre,p.apellido,es.nombre from empleado_instituto ei,instituto_salud i,";
        $sql.="empleado e,especialidad es,persona p where ei.id_instituto_salud=i.id and ei.id_empleado=e.id";
        $sql.=" and e.id_persona=p.id and e.id_especialidad=es.id and ei.id=$id_empleado_instituto";
        
    } 
    
    $db = new conexion();
    $resul = $db->consulta($sql);
    $num = $db->encontradas($resul);

    $datos.="";
    for ($i = 0; $i < $num; $i++) {
    $filas = mysql_fetch_array($resul);

        $datos.= $filas[0];
        $datos.="#";

        $datos.= $filas[1];
        $datos.="#";
        
        $datos.= $filas[2];
        $datos.="#";
        
        $datos.= $filas[3];
        $datos.="#";
        
        $datos.= $filas[4];
        $datos.="#";
    
    $datos.="@";
    }

    if ($num != 0) {
        return $datos;
    } else {
        return "No hay datos por mostrar";
    }
}

function obtenerCodigoEmpleadoInstituto($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto){
    
    if($nombre_emp==''||$apellido_emp='')
    {
        return "Ingrese el nombre de la empresa o el nombre del empleado de la especialidad";  
    }else{
        $db = new conexion();
        
        $id_empleado = obtenerCodigoEmpleado($nombre_emp,$apellido_emp,$nombre_especialidad);
        $id_instituto = obtenerCodigoInstitutoSalud($nombre_instituto);
                
        $sql = "select id from empleado_instituto where id_empleado=$id_empleado and id_instituto_salud=$id_instituto";
       
        $total_reg = $db->consulta($sql);
        $fila = mysql_fetch_array($total_reg,MYSQL_NUM);
        $id_empleado_instituto=$fila[0];
        
        return $id_empleado_instituto;
    } 
 
}

function agregarEmpleadoInstituto($id_instituto_salud,$id_empleado) 
{
    $db = new conexion(); 
    
    $sql ="INSERT INTO empleado_instituto(id_instituto_salud,id_empleado,estado)";
    $sql.=" VALUES($id_instituto_salud,$id_empleado,'Activo')";
    if ($db->consulta($sql) == 0) {
        return "No se Guardo el Empleado por Instituto";
    } else 
    {
        return "Se Guardo el Empleado por Instituto exitosamente";
    }
}

function modificaEmpleadoInstituto($id_empleado_instituto,$id_instituto_salud,$id_empleado,$estado) {
    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" id_instituto_salud=$id_instituto_salud,id_empleado=$id_empleado,estado='$estado'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Modifico el Empleado_Instituto";
    }else{
        return "Se Modifico el Empleado_Instituto exitosamente";
    }
}
               
function eliminaEmpleadoInstitutoPorNombre($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto) {

    $id_empleado_instituto=obtenerCodigoEmpleadoInstituto($nombre_emp,$apellido_emp,$nombre_especialidad,$nombre_instituto);
    
    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino Empleado por Instituto";
    }else{
        return "Se Elimino Empleado por Instituto exitosamente";
    }
}

function eliminaEmpleadoporInstituto($id_empleado_instituto) {

    $sql ="update empleado_instituto ";
    $sql.="set";
    $sql.=" estado='Inactivo'";
    $sql.=" where id=$id_empleado_instituto";
    
    $db = new conexion();
    if ($db->consulta($sql) == 0) {
        return "No se Elimino Empleado por Instituto";
    }else{
        return "Se Elimino Empleado por Instituto exitosamente";
    }
}
