-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-08-2016 a las 20:47:40
-- Versión del servidor: 5.6.26
-- Versión de PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_shc`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `antecedente`
--

CREATE TABLE IF NOT EXISTS `antecedente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `id_subtipo` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

CREATE TABLE IF NOT EXISTS `ciudad` (
  `id` int(11) NOT NULL,
  `id_provincia` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `composicion`
--

CREATE TABLE IF NOT EXISTS `composicion` (
  `id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE IF NOT EXISTS `consulta` (
  `id` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_empleado_instituto` int(11) NOT NULL,
  `fecha_consulta` datetime NOT NULL,
  `id_enfermedad` int(11) NOT NULL,
  `detalle_consulta` text NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta_etiqueta_examen_fisico`
--

CREATE TABLE IF NOT EXISTS `consulta_etiqueta_examen_fisico` (
  `id` int(11) NOT NULL,
  `id_consulta` int(11) NOT NULL,
  `id_etiqueta_examen` int(11) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_medida_terapeutica`
--

CREATE TABLE IF NOT EXISTS `detalle_medida_terapeutica` (
  `id` int(11) NOT NULL,
  `id_tratamiento` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `descripcion_medicamento` varchar(300) NOT NULL,
  `id_composicion` int(11) DEFAULT NULL,
  `cantidad_composicion` varchar(100) DEFAULT NULL,
  `indicacion` varchar(200) DEFAULT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_orden_examen_laboratorio`
--

CREATE TABLE IF NOT EXISTS `detalle_orden_examen_laboratorio` (
  `id` int(11) NOT NULL,
  `id_orden_examen` int(11) NOT NULL,
  `id_subtipo` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_tratamiento`
--

CREATE TABLE IF NOT EXISTS `detalle_tratamiento` (
  `id` int(11) NOT NULL,
  `id_prescripcion` int(11) NOT NULL,
  `descripcion` text,
  `id_tipo_tratamiento` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diagnostico`
--

CREATE TABLE IF NOT EXISTS `diagnostico` (
  `id` int(11) NOT NULL,
  `id_consulta` int(11) NOT NULL,
  `id_tipo_diagnostico` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE IF NOT EXISTS `direccion` (
  `id` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `direccion_residencia` varchar(100) NOT NULL,
  `direccion_trabajo` varchar(100) DEFAULT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE IF NOT EXISTS `empleado` (
  `id` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `id_especialidad` int(11) NOT NULL,
  `id_nivel_instruccion` int(11) DEFAULT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado_instituto`
--

CREATE TABLE IF NOT EXISTS `empleado_instituto` (
  `id` int(11) NOT NULL,
  `id_instituto_salud` int(11) NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `enfermedad`
--

CREATE TABLE IF NOT EXISTS `enfermedad` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad`
--

CREATE TABLE IF NOT EXISTS `especialidad` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_civil`
--

CREATE TABLE IF NOT EXISTS `estado_civil` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `etiqueta_antecedente`
--

CREATE TABLE IF NOT EXISTS `etiqueta_antecedente` (
  `id` int(11) NOT NULL,
  `id_antecedente` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `etiqueta_examen_fisico`
--

CREATE TABLE IF NOT EXISTS `etiqueta_examen_fisico` (
  `id` int(11) NOT NULL,
  `id_examen_fisico` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `etnia`
--

CREATE TABLE IF NOT EXISTS `etnia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen_fisico`
--

CREATE TABLE IF NOT EXISTS `examen_fisico` (
  `id` int(11) NOT NULL,
  `id_tipo_examen` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo_sanguineo`
--

CREATE TABLE IF NOT EXISTS `grupo_sanguineo` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instituto_salud`
--

CREATE TABLE IF NOT EXISTS `instituto_salud` (
  `id` int(11) NOT NULL,
  `ruc` int(11) NOT NULL,
  `razon_social` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `id_ciudad` int(11) NOT NULL,
  `direccion` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel_instruccion`
--

CREATE TABLE IF NOT EXISTS `nivel_instruccion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opcion`
--

CREATE TABLE IF NOT EXISTS `opcion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `url` text NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opcion_perfil`
--

CREATE TABLE IF NOT EXISTS `opcion_perfil` (
  `id` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL,
  `id_opcion` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_examen_laboratorio`
--

CREATE TABLE IF NOT EXISTS `orden_examen_laboratorio` (
  `id` int(11) NOT NULL,
  `id_consulta` int(11) NOT NULL,
  `fecha_orden` date NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE IF NOT EXISTS `paciente` (
  `id` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `id_grupo_sanguineo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente_etiqueta_antecedente`
--

CREATE TABLE IF NOT EXISTS `paciente_etiqueta_antecedente` (
  `id` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_etiqueta_antecedente` int(11) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE IF NOT EXISTS `perfil` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_usuario`
--

CREATE TABLE IF NOT EXISTS `perfil_usuario` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_perfil` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(11) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` varchar(30) NOT NULL,
  `ocupacion` varchar(100) NOT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `num_hijos` int(11) DEFAULT NULL,
  `id_ciudad_nacimiento` int(11) NOT NULL,
  `id_nivel_instruccion` int(11) DEFAULT NULL,
  `id_religion` int(11) NOT NULL,
  `id_estado_civil` int(11) NOT NULL,
  `id_etnia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prescripcion_medica`
--

CREATE TABLE IF NOT EXISTS `prescripcion_medica` (
  `id` int(11) NOT NULL,
  `id_consulta_diagnostico` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincia`
--

CREATE TABLE IF NOT EXISTS `provincia` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `religion`
--

CREATE TABLE IF NOT EXISTS `religion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultado_examen_laboratorio`
--

CREATE TABLE IF NOT EXISTS `resultado_examen_laboratorio` (
  `id` int(11) NOT NULL,
  `id_orden_examen` int(11) NOT NULL,
  `documento` blob NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtipo_antecedente`
--

CREATE TABLE IF NOT EXISTS `subtipo_antecedente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subtipo_examen_laboratorio`
--

CREATE TABLE IF NOT EXISTS `subtipo_examen_laboratorio` (
  `id` int(11) NOT NULL,
  `id_tipo_examen_lab` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefono`
--

CREATE TABLE IF NOT EXISTS `telefono` (
  `id` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `id_direccion` int(11) DEFAULT NULL,
  `telefono_fijo` varchar(12) NOT NULL,
  `telefono_movil` varchar(12) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_antecedente`
--

CREATE TABLE IF NOT EXISTS `tipo_antecedente` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_diagnostico`
--

CREATE TABLE IF NOT EXISTS `tipo_diagnostico` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_examen_fisico`
--

CREATE TABLE IF NOT EXISTS `tipo_examen_fisico` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_examen_laboratorio`
--

CREATE TABLE IF NOT EXISTS `tipo_examen_laboratorio` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_tratamiento`
--

CREATE TABLE IF NOT EXISTS `tipo_tratamiento` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `clave` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `antecedente`
--
ALTER TABLE `antecedente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `an_id_tipo_idx` (`id_tipo`),
  ADD KEY `an_id_subtipo_idx` (`id_subtipo`);

--
-- Indices de la tabla `ciudad`
--
ALTER TABLE `ciudad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cd_id_provincia_idx` (`id_provincia`);

--
-- Indices de la tabla `composicion`
--
ALTER TABLE `composicion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `co_id_paciente_idx` (`id_paciente`),
  ADD KEY `co_id_empleado_instituto_idx` (`id_empleado_instituto`),
  ADD KEY `co_id_enfermedad_idx` (`id_enfermedad`);

--
-- Indices de la tabla `consulta_etiqueta_examen_fisico`
--
ALTER TABLE `consulta_etiqueta_examen_fisico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ceef_id_consulta_idx` (`id_consulta`),
  ADD KEY `ceef_id_etiqueta_examen_idx` (`id_etiqueta_examen`);

--
-- Indices de la tabla `detalle_medida_terapeutica`
--
ALTER TABLE `detalle_medida_terapeutica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dmt_id_tratamiento_idx` (`id_tratamiento`);

--
-- Indices de la tabla `detalle_orden_examen_laboratorio`
--
ALTER TABLE `detalle_orden_examen_laboratorio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doel_id_orden_examen_idx` (`id_orden_examen`),
  ADD KEY `doel_id_subtipo_idx` (`id_subtipo`);

--
-- Indices de la tabla `detalle_tratamiento`
--
ALTER TABLE `detalle_tratamiento`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dt_id_prescripcion_idx` (`id_prescripcion`),
  ADD KEY `dt_id_tipo_tratamiento_idx` (`id_tipo_tratamiento`);

--
-- Indices de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `di_id_consulta_idx` (`id_consulta`),
  ADD KEY `di_id_tipo_diagnostico_idx` (`id_tipo_diagnostico`);

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dr_id_persona_idx` (`id_persona`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `em_id_persona_idx` (`id_persona`),
  ADD KEY `em_id_especialidad_idx` (`id_especialidad`),
  ADD KEY `em_nivel_instruccion_idx` (`id_nivel_instruccion`);

--
-- Indices de la tabla `empleado_instituto`
--
ALTER TABLE `empleado_instituto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ens_id_instituto_salud_idx` (`id_instituto_salud`),
  ADD KEY `ens_id_empleado_idx` (`id_empleado`);

--
-- Indices de la tabla `enfermedad`
--
ALTER TABLE `enfermedad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `etiqueta_antecedente`
--
ALTER TABLE `etiqueta_antecedente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ea_id_antecedente_idx` (`id_antecedente`);

--
-- Indices de la tabla `etiqueta_examen_fisico`
--
ALTER TABLE `etiqueta_examen_fisico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `eef_id_tipo_examen_idx` (`id_examen_fisico`);

--
-- Indices de la tabla `etnia`
--
ALTER TABLE `etnia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `examen_fisico`
--
ALTER TABLE `examen_fisico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ef_id_tipo_examen_idx` (`id_tipo_examen`);

--
-- Indices de la tabla `grupo_sanguineo`
--
ALTER TABLE `grupo_sanguineo`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `instituto_salud`
--
ALTER TABLE `instituto_salud`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_id_ciudad_idx` (`id_ciudad`);

--
-- Indices de la tabla `nivel_instruccion`
--
ALTER TABLE `nivel_instruccion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `opcion`
--
ALTER TABLE `opcion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `opcion_perfil`
--
ALTER TABLE `opcion_perfil`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oper_id_perfil_idx` (`id_perfil`),
  ADD KEY `oper_id_opcion_idx` (`id_opcion`);

--
-- Indices de la tabla `orden_examen_laboratorio`
--
ALTER TABLE `orden_examen_laboratorio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oel_id_consulta_idx` (`id_consulta`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pa_id_persona_idx` (`id_persona`),
  ADD KEY `pa_id_grupo_sanguineo_idx` (`id_grupo_sanguineo`);

--
-- Indices de la tabla `paciente_etiqueta_antecedente`
--
ALTER TABLE `paciente_etiqueta_antecedente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pea_id_paciente_idx` (`id_paciente`),
  ADD KEY `pea_id_etiqueta_antecedente_idx` (`id_etiqueta_antecedente`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `perfil_usuario`
--
ALTER TABLE `perfil_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ps_id_usuario_idx` (`id_usuario`),
  ADD KEY `ps_id_perfil_idx` (`id_perfil`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pr_id_ciudad_nacimiento` (`id_ciudad_nacimiento`),
  ADD KEY `pr_id_nivel_instruccion` (`id_nivel_instruccion`),
  ADD KEY `pr_id_religion` (`id_religion`),
  ADD KEY `pr_id_estado_civil` (`id_estado_civil`),
  ADD KEY `pr_id_etnia` (`id_etnia`);

--
-- Indices de la tabla `prescripcion_medica`
--
ALTER TABLE `prescripcion_medica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pm_id_consulta_diagnostico_idx` (`id_consulta_diagnostico`);

--
-- Indices de la tabla `provincia`
--
ALTER TABLE `provincia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `religion`
--
ALTER TABLE `religion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `resultado_examen_laboratorio`
--
ALTER TABLE `resultado_examen_laboratorio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oel_id_orden_examen_idx` (`id_orden_examen`);

--
-- Indices de la tabla `subtipo_antecedente`
--
ALTER TABLE `subtipo_antecedente`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `subtipo_examen_laboratorio`
--
ALTER TABLE `subtipo_examen_laboratorio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sel_id_tipo_examen_lab_idx` (`id_tipo_examen_lab`);

--
-- Indices de la tabla `telefono`
--
ALTER TABLE `telefono`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tl_id_persona_idx` (`id_persona`);

--
-- Indices de la tabla `tipo_antecedente`
--
ALTER TABLE `tipo_antecedente`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_diagnostico`
--
ALTER TABLE `tipo_diagnostico`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_examen_fisico`
--
ALTER TABLE `tipo_examen_fisico`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_examen_laboratorio`
--
ALTER TABLE `tipo_examen_laboratorio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_tratamiento`
--
ALTER TABLE `tipo_tratamiento`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `antecedente`
--
ALTER TABLE `antecedente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `ciudad`
--
ALTER TABLE `ciudad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `composicion`
--
ALTER TABLE `composicion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `consulta`
--
ALTER TABLE `consulta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `consulta_etiqueta_examen_fisico`
--
ALTER TABLE `consulta_etiqueta_examen_fisico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `detalle_medida_terapeutica`
--
ALTER TABLE `detalle_medida_terapeutica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `detalle_orden_examen_laboratorio`
--
ALTER TABLE `detalle_orden_examen_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `detalle_tratamiento`
--
ALTER TABLE `detalle_tratamiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `empleado_instituto`
--
ALTER TABLE `empleado_instituto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `enfermedad`
--
ALTER TABLE `enfermedad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `especialidad`
--
ALTER TABLE `especialidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `estado_civil`
--
ALTER TABLE `estado_civil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `etiqueta_antecedente`
--
ALTER TABLE `etiqueta_antecedente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `etiqueta_examen_fisico`
--
ALTER TABLE `etiqueta_examen_fisico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `etnia`
--
ALTER TABLE `etnia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `examen_fisico`
--
ALTER TABLE `examen_fisico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `grupo_sanguineo`
--
ALTER TABLE `grupo_sanguineo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `instituto_salud`
--
ALTER TABLE `instituto_salud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `nivel_instruccion`
--
ALTER TABLE `nivel_instruccion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `opcion`
--
ALTER TABLE `opcion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `opcion_perfil`
--
ALTER TABLE `opcion_perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `orden_examen_laboratorio`
--
ALTER TABLE `orden_examen_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `paciente_etiqueta_antecedente`
--
ALTER TABLE `paciente_etiqueta_antecedente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `perfil_usuario`
--
ALTER TABLE `perfil_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `prescripcion_medica`
--
ALTER TABLE `prescripcion_medica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `provincia`
--
ALTER TABLE `provincia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `religion`
--
ALTER TABLE `religion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `resultado_examen_laboratorio`
--
ALTER TABLE `resultado_examen_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `subtipo_antecedente`
--
ALTER TABLE `subtipo_antecedente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `subtipo_examen_laboratorio`
--
ALTER TABLE `subtipo_examen_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `telefono`
--
ALTER TABLE `telefono`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipo_antecedente`
--
ALTER TABLE `tipo_antecedente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipo_diagnostico`
--
ALTER TABLE `tipo_diagnostico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipo_examen_fisico`
--
ALTER TABLE `tipo_examen_fisico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipo_examen_laboratorio`
--
ALTER TABLE `tipo_examen_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipo_tratamiento`
--
ALTER TABLE `tipo_tratamiento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `antecedente`
--
ALTER TABLE `antecedente`
  ADD CONSTRAINT `fk1_antecedente` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_antecedente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_antecedente` FOREIGN KEY (`id_subtipo`) REFERENCES `subtipo_antecedente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `ciudad`
--
ALTER TABLE `ciudad`
  ADD CONSTRAINT `fk1_ciudad` FOREIGN KEY (`id_provincia`) REFERENCES `provincia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `consulta`
--
ALTER TABLE `consulta`
  ADD CONSTRAINT `fk1_consulta` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_consulta` FOREIGN KEY (`id_empleado_instituto`) REFERENCES `empleado_instituto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk3_consulta` FOREIGN KEY (`id_enfermedad`) REFERENCES `enfermedad` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `consulta_etiqueta_examen_fisico`
--
ALTER TABLE `consulta_etiqueta_examen_fisico`
  ADD CONSTRAINT `fk1_consulta_etiqueta_examen_fisico` FOREIGN KEY (`id_consulta`) REFERENCES `consulta` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_consulta_etiqueta_examen_fisico` FOREIGN KEY (`id_etiqueta_examen`) REFERENCES `etiqueta_examen_fisico` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_medida_terapeutica`
--
ALTER TABLE `detalle_medida_terapeutica`
  ADD CONSTRAINT `fk1_detalle_medida_terapeutica` FOREIGN KEY (`id_tratamiento`) REFERENCES `detalle_tratamiento` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_orden_examen_laboratorio`
--
ALTER TABLE `detalle_orden_examen_laboratorio`
  ADD CONSTRAINT `fk1_detalle_orden_examen_laboratorio` FOREIGN KEY (`id_orden_examen`) REFERENCES `orden_examen_laboratorio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_detalle_orden_examen_laboratorio` FOREIGN KEY (`id_subtipo`) REFERENCES `subtipo_examen_laboratorio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_tratamiento`
--
ALTER TABLE `detalle_tratamiento`
  ADD CONSTRAINT `fk1_detalle_tratamiento` FOREIGN KEY (`id_prescripcion`) REFERENCES `prescripcion_medica` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_detalle_tratamiento` FOREIGN KEY (`id_tipo_tratamiento`) REFERENCES `tipo_tratamiento` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `diagnostico`
--
ALTER TABLE `diagnostico`
  ADD CONSTRAINT `fk1_diagnostico` FOREIGN KEY (`id_consulta`) REFERENCES `consulta` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_diagnostico` FOREIGN KEY (`id_tipo_diagnostico`) REFERENCES `tipo_diagnostico` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `direccion`
--
ALTER TABLE `direccion`
  ADD CONSTRAINT `fk1_direccion` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD CONSTRAINT `fk1_empleado` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_empleado` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidad` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `empleado_instituto`
--
ALTER TABLE `empleado_instituto`
  ADD CONSTRAINT `fk1_empleado_instituto` FOREIGN KEY (`id_instituto_salud`) REFERENCES `instituto_salud` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_empleado_instituto` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `etiqueta_antecedente`
--
ALTER TABLE `etiqueta_antecedente`
  ADD CONSTRAINT `fk1_etiqueta_antecedente` FOREIGN KEY (`id_antecedente`) REFERENCES `antecedente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `etiqueta_examen_fisico`
--
ALTER TABLE `etiqueta_examen_fisico`
  ADD CONSTRAINT `fk1_etiqueta_examen_fisico` FOREIGN KEY (`id_examen_fisico`) REFERENCES `examen_fisico` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `examen_fisico`
--
ALTER TABLE `examen_fisico`
  ADD CONSTRAINT `fk1_examen_fisico` FOREIGN KEY (`id_tipo_examen`) REFERENCES `tipo_examen_fisico` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `instituto_salud`
--
ALTER TABLE `instituto_salud`
  ADD CONSTRAINT `fk1_instituto_salud` FOREIGN KEY (`id_ciudad`) REFERENCES `ciudad` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `opcion_perfil`
--
ALTER TABLE `opcion_perfil`
  ADD CONSTRAINT `fk1_opcion_perfil` FOREIGN KEY (`id_perfil`) REFERENCES `perfil` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_opcion_perfil` FOREIGN KEY (`id_opcion`) REFERENCES `opcion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `orden_examen_laboratorio`
--
ALTER TABLE `orden_examen_laboratorio`
  ADD CONSTRAINT `fk1_orden_examen_laboratorio` FOREIGN KEY (`id_consulta`) REFERENCES `consulta` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD CONSTRAINT `fk1_paciente` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_paciente` FOREIGN KEY (`id_grupo_sanguineo`) REFERENCES `grupo_sanguineo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `paciente_etiqueta_antecedente`
--
ALTER TABLE `paciente_etiqueta_antecedente`
  ADD CONSTRAINT `fk1_paciente_etiqueta_antecedente` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_paciente_etiqueta_antecedente` FOREIGN KEY (`id_etiqueta_antecedente`) REFERENCES `etiqueta_antecedente` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `perfil_usuario`
--
ALTER TABLE `perfil_usuario`
  ADD CONSTRAINT `fk1_perfil_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_perfil_usuario` FOREIGN KEY (`id_perfil`) REFERENCES `perfil` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `fk1_persona` FOREIGN KEY (`id_ciudad_nacimiento`) REFERENCES `ciudad` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk2_persona` FOREIGN KEY (`id_religion`) REFERENCES `religion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk3_persona` FOREIGN KEY (`id_estado_civil`) REFERENCES `estado_civil` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk4_persona` FOREIGN KEY (`id_etnia`) REFERENCES `etnia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `prescripcion_medica`
--
ALTER TABLE `prescripcion_medica`
  ADD CONSTRAINT `fk1_prescripcion_medica` FOREIGN KEY (`id_consulta_diagnostico`) REFERENCES `diagnostico` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `resultado_examen_laboratorio`
--
ALTER TABLE `resultado_examen_laboratorio`
  ADD CONSTRAINT `fk1_resultado_examen_laboratorio` FOREIGN KEY (`id_orden_examen`) REFERENCES `orden_examen_laboratorio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `subtipo_examen_laboratorio`
--
ALTER TABLE `subtipo_examen_laboratorio`
  ADD CONSTRAINT `fk1_subtipo_examen_laboratorio` FOREIGN KEY (`id_tipo_examen_lab`) REFERENCES `tipo_examen_laboratorio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `telefono`
--
ALTER TABLE `telefono`
  ADD CONSTRAINT `fk1_telefono` FOREIGN KEY (`id_persona`) REFERENCES `persona` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
